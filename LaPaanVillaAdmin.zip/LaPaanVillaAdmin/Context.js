import React from 'react';

export default React.createContext({
    notificationSlug: undefined , 
    isRefresh: false
});