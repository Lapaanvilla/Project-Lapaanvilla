export const EDFonts = {
  // bold: "Lato-Bold",
  // medium: "Lato-Black",
  // semiBold: "Lato-Regular",
  // regular: "Lato-Regular",
  // light: "Lato-Light"
  bold: "Gilroy-Bold",
  semibold: "Gilroy-SemiBold",
  extrabold: "Gilroy-ExtraBold",
    medium: "Gilroy-Medium",
    regular: "Gilroy-Regular",
    light: "Gilroy-Light",
  ultralight: "Gilroy-UltraLight",
    satisfy: "Satisfy-Regular",
    black: "Gilroy-Black",
    boldItalic: "Gilroy-BoldItalic",
    heavy: "Gilroy-Heavy",
    thin: "Gilroy-Thin",
};
