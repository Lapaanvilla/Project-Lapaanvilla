import Moment from "moment";
import React from "react";
import { StyleSheet, Text, TextInput, TouchableOpacity, View, FlatList, Platform } from "react-native";
import { Icon } from "react-native-elements";
import { NavigationActions, StackActions, NavigationEvents } from "react-navigation";
import { connect } from "react-redux";
import EDRTLText from "../components/EDRTLText";
import EDRTLView from "../components/EDRTLView";
import ProgressLoader from "../components/ProgressLoader";
import { strings } from "../locales/i18n";
import { saveCartCount, saveCheckoutDetails } from "../redux/actions/Checkout";
import { clearCartData, clearCurrency_Symbol } from "../utils/AsyncStorageHelper";
import { showDialogue, showValidationAlert, showNoInternetAlert, showPaymentDialogue } from "../utils/EDAlert";
import { EDColors } from "../utils/EDColors";
import { debugLog, funGetFrench_Curr, getProportionalFontSize, isRTLCheck, RESPONSE_SUCCESS, RESTAURANT_ERROR, PAYMENT_TYPES, TextFieldTypes, CARD_BRANDS, RETURN_URL, COUPON_ERROR } from "../utils/EDConstants";
import { EDFonts } from "../utils/EDFontConstants";
import { netStatus } from "../utils/NetworkStatusConnection";
import { addOrder, getPayLaterOrdersAPI, updatePendingOrdersAPI, applyCouponAPI, getPaymentList, getSavedCardsAPI, createPaymentMethod, checkCardPayment, addToCart } from "../utils/ServiceManager";
import BaseContainer from "./BaseContainer";
import { saveWalletMoneyInRedux, saveTableIDInRedux, saveResIDInRedux } from "../redux/actions/User";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { SvgXml } from "react-native-svg";
import { discount_icon, paylater_icon } from "../utils/EDSvgIcons";
import EDThemeButton from "../components/EDThemeButton";
import metrics from "../utils/metrics";
import { CreditCardInput } from "react-native-credit-card-input";
import Assets from "../assets";
import EDPopupView from "../components/EDPopupView";
import { Spinner } from "native-base";
import WebView from "react-native-webview";
import * as RNLocalize from "react-native-localize";

export class PaymentContainer extends React.PureComponent {
    //#region LIFE CYCLE METHODS

    constructor(props) {
        super(props);

        this.checkoutDetail = this.props.checkoutDetail;
        this.currecy_code = this.props.navigation.getParam("currency_code")

        this.isPendingAdded = this.props.navigation.state.params != undefined
            && this.props.navigation.state.params.isPendingAdded != undefined
            && this.props.navigation.state.params.isPendingAdded !== null
            ? this.props.navigation.state.params.isPendingAdded : ''

        this.pendingTotalPayment = this.props.navigation.state.params != undefined
            && this.props.navigation.state.params.pendingTotalPayment != undefined
            && this.props.navigation.state.params.pendingTotalPayment !== null
            ? this.props.navigation.state.params.pendingTotalPayment : ''

        this.resContentId = this.props.navigation.state.params != undefined
            && this.props.navigation.state.params.resContentId != undefined
            && this.props.navigation.state.params.resContentId !== null
            ? this.props.navigation.state.params.resContentId : ''

        this.extra_comment = this.props.navigation.state.params != undefined
            && this.props.navigation.state.params.extra_comment != undefined
            && this.props.navigation.state.params.extra_comment !== null
            ? this.props.navigation.state.params.extra_comment : ''

        this.addToCartData = this.props.navigation.state.params != undefined
            && this.props.navigation.state.params.addToCartData != undefined
            && this.props.navigation.state.params.addToCartData !== null
            ? this.props.navigation.state.params.addToCartData : {}

        this.allowPayLater = "1"
        this.oldOrderID = undefined
        this.promoCode = undefined
        this.promoObj = {}
        this.oldTotal = "0.00"
        this.oldSubtotal = 0
        this.promoArray = []
        this.used_coupons = []
        this.old_credit_fee = 0
    }

    state = {
        isLoading: false,
        strComment: "",
        later: false,
        cashOn: false,
        online: false,
        showPayLater: false,
        pendingOrderArray: undefined,
        totalPendingAmount: 0,
        payPending: this.props.checkoutDetail.order_delivery == "DineIn" ? false : true,
        totalPrice: 0,
        order_delivery: this.props.checkoutDetail.order_delivery,
        disableToggle: this.props.checkoutDetail.order_delivery == "DineIn" ? false : true,
        discountedPrice: undefined,
        selectedOption: '',
        showCardInput: true,
        isDefaultCard: false,
        noDefaultCard: false,
        defaultCard: undefined,
        isSavedCardLoading: false,
        isCardSave: false,
        url: undefined,
        countryCode: undefined,
        cardError: "",
        isPaymentLoading: false,
        promoLoading: false


    };

    /**
 * @param { Success Reponse Object } onSuccess
 */
    onSuccessOrderListing = (onSuccess) => {
        debugLog("ORDER DETAIL LIST ::::::::::::: ", onSuccess)
        if (onSuccess != undefined && onSuccess.status == RESPONSE_SUCCESS) {
            if (onSuccess.dineIn.length > 0) {
                let pending = onSuccess.dineIn
                this.oldOrderID = pending[0].order_id
                this.oldSubtotal = pending[0].price.filter(data => data.label_key === "Sub Total")[0].value
                this.oldTotal = pending[0].price.filter(data => data.label_key === "Total")[0].value

                let totalPending = this.oldSubtotal
                // pending.map(data => {
                //     debugLog("TEST :::::", data)
                //     totalPending = totalPending + parseFloat(data.total)
                // })
                debugLog("TOTAL PENDING AMOUNT :::::", totalPending)
                this.setState({
                    pendingOrderArray: pending, totalPendingAmount: totalPending, totalPrice: this.state.totalPrice + parseFloat(totalPending),
                    payPending: true, later: false
                })
            } else {
                debugLog("NO PENDING ORDERS FOUND :::::")
            }
            this.setState({ isLoading: false });
        } else {
            debugLog('NOT GETTING ORDER LIST')
            this.setState({ isLoading: false });
        }
    }


    /**
     * @param { Failure Response Object } onFailure
     */
    onFailureOrderListing = (onFailure) => { // ERROR 405
        debugLog(':::::::::: FAILED TO GET ORDER', onFailure)
        this.setState({ isLoading: false });
    }

    /** GET PENDING ORDER API */
    getPendingOrderData() {
        netStatus(isConnected => {
            if (isConnected) {
                this.setState({ isLoading: true });
                let param = {
                    user_id: parseInt(this.props.userID) || 0,
                    // token: this.props.token,
                    language_slug: this.props.lan,
                }
                getPayLaterOrdersAPI(param, this.onSuccessOrderListing, this.onFailureOrderListing, this.props);
            } else {
                showNoInternetAlert()
            }
        })
    }

    onWillFocusPayment = () => {



        if (this.checkoutDetail.order_delivery == "DineIn" && this.allowPayLater !== undefined && this.allowPayLater === "1") {
            this.setState({ showPayLater: true })
        }
        this.setState({ totalPrice: this.checkoutDetail.total, payPending: false })
        this.getPaymentOptionsAPI()

        this.getPendingOrderData()

    }

    getPaymentOptionsAPI = () => {
        netStatus(isConnected => {
            if (isConnected) {
                this.setState({ isPaymentLoading: true })

                var params = {
                    language_slug: this.props.lan,
                    user_id: this.props.userID,
                    is_dine_in: '1',
                    restaurant_id: this.checkoutDetail.restaurant_id,
                    isLoggedIn: (this.props.userID !== undefined && this.props.userID !== null && this.props.userID !== "") ? 1 : 0
                }

                getPaymentList(params, this.onSuccessPaymentList, this.onFailurePaymentList, this.props)
            } else {
                showNoInternetAlert()
            }
        })
    }

    onSuccessPaymentList = onSuccess => {
        console.log(':::::::: PAYMENT SUCCESS', onSuccess)
        if (onSuccess.Payment_method !== undefined && onSuccess.Payment_method !== null && onSuccess.Payment_method.length !== 0) {
            this.paymentOptions = onSuccess.Payment_method


            //FETCH SAVED CARDS IN STRIPE PAYMENT IF SUPPORTED
            if (this.props.userID !== undefined && this.props.userID !== null && this.paymentOptions.map(data =>
                data.payment_gateway_slug
            ).includes("stripe"))
                this.fetchCards()

            // if (this.state.selectedOption !== "stripe")
            // this.setState({ selectedOption: onSuccess.Payment_method[0].payment_gateway_slug })
            this.setState({
                selectedOption: onSuccess.Payment_method[0].payment_gateway_slug, cashOn:
                    onSuccess.Payment_method[0].payment_gateway_slug == "cod"
                , later: onSuccess.Payment_method[0].payment_gateway_slug == "paylater", online: false, disableToggle: false, payPending: false, totalPrice: this.state.totalPrice - parseFloat(this.state.totalPendingAmount)
            })

            if (onSuccess.Payment_method[0].payment_gateway_slug == "razorpay") {
				this.razorpayDetails = onSuccess.Payment_method[0]
			}

            this.forceUpdate();

            // this.setState({ selectedOption: onSuccess.Payment_method[0].payment_gateway_slug })
            // console.log(':::::::: calling SUCCESS', onSuccess.Payment_method[0])
            // this.onOptionSelection(onSuccess.Payment_method[0]);
            console.log(':::::::: called SUCCESS', onSuccess.Payment_method[0])
            if (this.props.checkoutDetail.order_delivery == "DineIn") {
                this.paymentOptions.push({
                    "PaymentMethod": null,
                    "client_id": null,
                    "client_secret": null,
                    "display_name_ar": "الدفع لاحقًا",
                    "display_name_en": "Pay Later",
                    "display_name_fr": "Payer plus tard",
                    "failure_url": RETURN_URL + "/payment_confirm",
                    "payment_gateway_slug": "paylater",
                    "payment_id": "999",
                    "payment_method": null,
                    "payment_url": null,
                    "return_url": RETURN_URL + "/payment_confirm",
                    "sorting": "1",
                    "status": "1",
                    "success_url": RETURN_URL + "/payment_success",
                    "valid_currency": "usd"
                })
            }
            this.forceUpdate();
        }
        if (this.paymentOptions !== undefined &&
            this.paymentOptions !== null &&
            this.paymentOptions.length !== 0
        )
            this.addToCartData.is_creditcard = (this.paymentOptions[0].payment_gateway_slug == "paylater" || this.paymentOptions[0].payment_gateway_slug == "cod") ? "no" : "yes"
        else
            this.addToCartData.is_creditcard = "no"
        this.getCartData()
        this.setState({ isPaymentLoading: false })

    }

    onFailurePaymentList = onFailure => {
        console.log('::::::::::: PAYMENT FALURE', onFailure)
        showValidationAlert(onFailure.message)
        this.setState({ isPaymentLoading: false })
    }



    togglePending = () => {
        if (!this.state.disableToggle) {
            this.setState({
                payPending: true, totalPrice: parseFloat(this.checkoutDetail.total) + parseFloat(this.state.totalPendingAmount), later: false,
                online:
                    this.paymentOptions !== null &&
                        this.paymentOptions.length !== 0 &&
                        this.paymentOptions[0].payment_gateway_slug !== "cod" ? false :
                        true,
                cashOn:
                    this.paymentOptions !== null &&
                    this.paymentOptions.length !== 0 &&
                    this.paymentOptions[0].payment_gateway_slug == "cod"
                , selectedOption:
                    this.paymentOptions !== undefined &&
                        this.paymentOptions !== null &&
                        this.paymentOptions.length !== 0 &&
                        this.paymentOptions[0].payment_gateway_slug !== "paylater" ?
                        this.paymentOptions[0].payment_gateway_slug : ''
            })
        }
        this.getCartData()
    }

    navigateToPendingOrders = () => {
        this.props.navigation.navigate("PendingOrdersFromCart", { orderDetails: this.state.pendingOrderArray })
    }


    myValidatePostalCode(postalCode) {
        return postalCode.match(/^\d{5,6}$/) ? "valid" :
            postalCode.length > 6 ? "invalid" :
                "incomplete";
    }

    /**
   * On Credit card input
   */
    onCCInput = (data) => {
        this.isCardError = false
        this.isExpiryError = false
        this.isCVCError = false
        this.isCountryError = false
        this.isPostalError = false

        this.setState({ cardError: "" })
        this.cardData = data
    }

    validateCard = () => {
        if (this.cardData !== undefined) {
            if (this.cardData.status.number == "valid") {
                if (this.cardData.status.expiry == "valid") {
                    if (this.isForEditing || this.cardData.status.cvc == "valid") {
                        if (this.selectedCountry !== undefined || this.state.countryCode !== undefined) {
                            if (this.cardData.status.postalCode == "valid") {
                                this.isCardError = false
                                this.isExpiryError = false
                                this.isCVCError = false
                                this.isCountryError = false
                                this.isPostalError = false
                                this.setState({ cardError: "" })

                            }
                            else {
                                this.isPostalError = true
                                this.setState({ cardError: strings("invalidPostal") })
                            }
                        }
                        else {
                            this.isCountryError = true
                            this.setState({ cardError: strings("noCountry") })
                        }
                    }
                    else {
                        this.isCVCError = true
                        console.log("Invalid CVC")
                        this.setState({ cardError: strings("invalidCVC") })
                    }
                }
                else {
                    this.isExpiryError = true
                    console.log("Invalid expiry date", this.state.cardError)
                    this.setState({ cardError: strings("invalidExpiry") })
                }
            }
            else {
                this.isCardError = true
                console.log("Invalid card number")
                this.setState({ cardError: this.cardData.values.number == '' ? strings("nocardData") : strings("invalidCard") })
            }
        }
        else {
            this.isCardError = true
            this.setState({ cardError: strings("nocardData") })
        }

        return this.isCardError === false &&
            this.isExpiryError === false &&
            this.isCVCError === false &&
            this.isCountryError === false &&
            this.isPostalError === false;
    }


    fetchCards = () => {
        this.state.defaultCard = undefined
        this.state.noDefaultCard = false
        netStatus(status => {
            if (status) {
                this.setState({ isSavedCardLoading: true })
                let userParams = {
                    language_slug: this.props.lan,
                    user_id: this.props.userID,
                    isLoggedIn: 1
                }
                getSavedCardsAPI(userParams, this.onSuccessFetchCards, this.onFailureFetchCards, this.props)
            }
            else {
                this.setState({ isSavedCardLoading: false });
            }
        })
    }

    onSuccessFetchCards = onSuccess => {
        this.noCards = false

        if (onSuccess.stripe_response !== undefined &&
            onSuccess.stripe_response !== null &&
            onSuccess.stripe_response.length !== 0
        ) {

            let valid_cards = []
            valid_cards = onSuccess.stripe_response.filter(cardData => { return new Date() < new Date().setFullYear(cardData.card.exp_year, cardData.card.exp_month, 1) })
            this.setState({
                noDefaultCard: !(valid_cards !== undefined && valid_cards !== null && valid_cards.length !== 0 && valid_cards[0].is_default_card == "1"),
                showCardInput: false,
                defaultCard: valid_cards !== undefined && valid_cards !== null && valid_cards.length !== 0 && valid_cards[0].is_default_card == "1" ? valid_cards[0] : undefined
            })
        }
        else {
            debugLog("NO CARDS ::::::")
            this.noCards = true

        }

        this.setState({ isSavedCardLoading: false });
    }

    onFailureFetchCards = onFailure => {
        this.setState({ isSavedCardLoading: false });
    }








    createPaymentList = item => {
        let display_name = `display_name_${this.props.lan}`
        return (

            <View>
                <TouchableOpacity style={[style.subContainer]}
                    activeOpacity={1}
                    onPress={() => this.onOptionSelection(item.item)}>
                    <EDRTLView>
                        <EDRTLView style={{ alignItems: 'center', flex: 1 }}>
                            {item.item.payment_gateway_slug === 'paylater' ?
                                <SvgXml xml={paylater_icon} fill={this.state.selectedOption == item.item.payment_gateway_slug ? EDColors.primary : EDColors.text} size={20} /> :
                                <Icon name={
                                    item.item.payment_gateway_slug === 'applepay' ? 'apple-pay'
                                        :
                                        item.item.payment_gateway_slug === 'paypal' ? 'paypal' : item.item.payment_gateway_slug === 'cod' ? 'account-balance-wallet' : 'credit-card'}
                                    type={
                                        item.item.payment_gateway_slug === 'applepay' ? 'fontisto' :
                                            item.item.payment_gateway_slug === 'paypal' ? 'entypo' : item.item.payment_gateway_slug === 'cod' ? 'material' : 'material'}
                                    size={20} color={this.state.selectedOption == item.item.payment_gateway_slug ? EDColors.primary : EDColors.text}
                                    style={style.paymentIconStyle} />}

                            <EDRTLText style={[style.paymentMethodTitle, { color: this.state.selectedOption == item.item.payment_gateway_slug ? EDColors.black : EDColors.blackSecondary }]} title={
                                item.item[display_name]} />
                        </EDRTLView>
                        <Icon name={"check"} size={getProportionalFontSize(16)} selectionColor={EDColors.primary} color={this.state.selectedOption == item.item.payment_gateway_slug ? EDColors.primary : EDColors.white} style={{ margin: 10 }} />
                    </EDRTLView>
                    {this.state.selectedOption == "stripe" && item.item.payment_gateway_slug == "stripe" ?
                        <>
                            {!this.state.showCardInput ?
                                this.state.defaultCard !== undefined ?
                                    <>
                                        <EDRTLView style={[style.cardView]}>
                                            <EDRTLView style={style.cardSubView}>
                                                <Icon
                                                    name={this.state.defaultCard.card.brand == CARD_BRANDS.visa ? "cc-visa" :
                                                        this.state.defaultCard.card.brand == CARD_BRANDS.mastercard ? "cc-mastercard" :
                                                            this.state.defaultCard.card.brand == CARD_BRANDS.amex ? "cc-amex" : "credit-card"
                                                    }
                                                    color={this.state.defaultCard.card.brand == CARD_BRANDS.visa ? EDColors.visa :
                                                        this.state.defaultCard.card.brand == CARD_BRANDS.mastercard ? EDColors.mastercard :
                                                            this.state.defaultCard.card.brand == CARD_BRANDS.amex ? EDColors.amex : EDColors.primary
                                                    }
                                                    size={20}
                                                    type="font-awesome"
                                                />
                                                <View style={{ marginHorizontal: 20, flex: 1 }}>
                                                    <EDRTLView style={{ alignItems: 'center' }}>
                                                        <Text style={{ color: EDColors.black }}>•••• </Text>
                                                        <EDRTLText title={this.state.defaultCard.card.last4} style={style.last4Text} />
                                                    </EDRTLView>
                                                    {(new Date().setFullYear(this.state.defaultCard.card.exp_year, this.state.defaultCard.card.exp_month, 1) < new Date()) ?
                                                        <EDRTLText title={strings("expired")} style={style.expiredText} /> : null}
                                                </View>
                                                <EDRTLText title={strings("change")} style={style.changeCard} onPress={this.changeCard} />
                                                <EDRTLText title={
                                                    strings("homeNew")} style={style.changeCard} onPress={this.addCard} />

                                            </EDRTLView>
                                        </EDRTLView>
                                        <EDRTLText title={strings("defaultCard")} style={{ fontFamily: EDFonts.regular, color: EDColors.textNew, marginHorizontal: 7.5, flex: 1, fontSize: getProportionalFontSize(14), marginTop: 10 }} />

                                    </> :

                                    this.state.isLoading || this.state.isPaymentLoading || this.state.isSavedCardLoading ? null :
                                        <>
                                            <EDRTLText title={
                                                this.noCards ?
                                                    strings("noCards") :
                                                    strings("noDefaultCard")} style={{ fontFamily: EDFonts.regular, color: EDColors.error, marginHorizontal: 7.5, flex: 1, fontSize: getProportionalFontSize(14), marginTop: 10 }} />
                                            <EDRTLView style={{ alignItems: 'center', marginTop: 10, }}>
                                                {this.noCards ? null :
                                                    <EDRTLText title={strings("setNow")} style={[style.changeCard, { marginLeft: 7.5 }]} onPress={this.changeCard} />}
                                                <EDRTLText title={strings("homeNew")} style={style.changeCard} onPress={this.addCard} />
                                            </EDRTLView>
                                        </>


                                : null}
                            {this.state.showCardInput ?
                                < View style={{}}>
                                    {this.state.defaultCard !== undefined || this.state.noDefaultCard ?
                                        <EDRTLText title={
                                            strings("dialogCancel")} style={[style.changeCard, { textAlign: 'left', marginLeft: 0 }]} onPress={this.addCard} /> : null}
                                    <CreditCardInput
                                        ref={ref => this.creditcardRef = ref}
                                        autoFocus={false}
                                        onChange={this.onCCInput}
                                        cardFontFamily={EDFonts.regular}
                                        cardImageFront={Assets.card_front}
                                        cardImageBack={Assets.card_back}
                                        errorMessage={this.state.cardError}
                                        isCardError={this.isCardError}
                                        isExpiryError={this.isExpiryError}
                                        isCVCError={this.isCVCError}
                                        isPostalError={this.isPostalError}
                                        isCountryError={this.isCountryError}
                                        onCountrySelect={this.onStripeCountrySelect}
                                        requiresPostalCode
                                        requiresCVC={true}
                                        // requiresCountry={this.order_delivery == "Delivery"}
                                        requiresCountry={true}
                                        dialCode={this.state.countryCode}
                                        isReadOnly={false}
                                        validatePostalCode={this.myValidatePostalCode}
                                        countryData={this.props.countryArray}
                                        cvcStyle={{ width: metrics.screenWidth / 2 - 40, marginLeft: 15 }}
                                        expiryStyle={{ width: metrics.screenWidth / 2 - 40 }}
                                        errorLeftPadding={metrics.screenWidth / 2 - 25}
                                    />
                                    {this.props.userID !== undefined && this.props.userID !== null && this.props.userID !== "" ?
                                        <TouchableOpacity onPress={this.toggleCardSave} activeOpacity={1}>
                                            <EDRTLView style={{ alignItems: 'center', marginTop: 10 }}>
                                                <Icon name={this.state.isCardSave ? "check-square-o" : "square-o"}
                                                    color={EDColors.primary}
                                                    size={20}
                                                    type="font-awesome"
                                                />
                                                <EDRTLText title={strings("askSaveCard")} style={{ fontFamily: EDFonts.medium, color: EDColors.black, marginHorizontal: 7.5, flex: 1, fontSize: getProportionalFontSize(14) }} />
                                            </EDRTLView>
                                        </TouchableOpacity> : null}

                                    {this.props.userID !== undefined && this.props.userID !== null && this.props.userID !== "" && this.state.isCardSave && !this.noCards ?
                                        <TouchableOpacity onPress={this.toggleCardDefault} activeOpacity={1}>
                                            <EDRTLView style={{ alignItems: 'center', marginTop: 10 }}>
                                                <Icon name={this.state.isDefaultCard ? "check-square-o" : "square-o"}
                                                    color={EDColors.primary}
                                                    size={20}
                                                    type="font-awesome"
                                                />
                                                <EDRTLText title={strings("setDefaultCard")} style={{ fontFamily: EDFonts.medium, color: EDColors.black, marginHorizontal: 7.5, flex: 1, fontSize: getProportionalFontSize(14) }} />
                                            </EDRTLView>
                                        </TouchableOpacity> : null}
                                </View> : null}</>

                        : null}
                </TouchableOpacity>
            </View >
        )
    }


    onStripeCountrySelect = country => {
        this.isCountryError = false
        this.selectedCountry = country
        debugLog("COUNTRY :::::", country)
        this.setState({ cardError: '', countryCode: undefined })
    }


    toggleCardSave = () => {
        this.setState({ isCardSave: !this.state.isCardSave, isDefaultCard: false })
    }

    toggleCardDefault = () => {
        this.setState({ isDefaultCard: !this.state.isDefaultCard })
    }

    changeCard = () => {
        this.props.navigation.push('savedCards', { isForAddressList: true, });

    }

    addCard = () => {
        this.setState({ showCardInput: !this.state.showCardInput })
    }

    refreshDefaultCard = (card) => {
        this.setState({ defaultCard: card })
    }


    onOptionSelection = data => {
        if (data.payment_gateway_slug == "cod") {

            {
                this.addToCartData.is_creditcard = "no"

                this.setState({ cashOn: true, online: false, later: false, selectedOption: data.payment_gateway_slug })
                if (this.state.totalPendingAmount !== 0)
                    this.setState({ payPending: true, totalPrice: parseFloat(this.checkoutDetail.total) + parseFloat(this.state.totalPendingAmount), later: false, disableToggle: true })
            }
            this.getCartData()

        }
        else if (data.payment_gateway_slug == "paylater") {



            this.promoArray = []
            this.setState({ selectedOption: data.payment_gateway_slug, cashOn: false, later: true, online: false, disableToggle: false, payPending: false, totalPrice: this.state.totalPrice - parseFloat(this.state.totalPendingAmount) })
            this.addToCartData.is_creditcard = "no"
            this.getCartData()
        }
        else {
            this.addToCartData.is_creditcard = "yes"
            this.getCartData()

            if (data.payment_gateway_slug == "razorpay") {
                this.razorpayDetails = data
            }
            this.setState({ cashOn: false, online: true, later: false, selectedOption: data.payment_gateway_slug })
            if (this.state.totalPendingAmount !== 0)
                this.setState({ payPending: true, totalPrice: parseFloat(this.checkoutDetail.total) + parseFloat(this.state.totalPendingAmount), later: false, disableToggle: true })
        }
    }




    /**
* Webview Navigation change
*/
    navigationChange = (resp) => {
        // debugLog("NAVIGATION CHANGE CALLED :::::::::::", resp)
        if (resp.url.includes(RETURN_URL + "/?payment_intent")) {
            this.setState({ url: undefined })
            this.checkCardPayment()
        }
    }

    checkCardPayment = () => {
        netStatus(
            status => {
                if (status) {
                    this.setState({ isLoading: true })
                    var params = {
                        trans_id: this.txn_id,
                        language_slug: this.props.lan
                    }
                    checkCardPayment(params, this.onCheckCardPaymentSuccess, this.onCheckCardPaymentFailure, this.props)
                }
                else {
                    showNoInternetAlert();
                    this.setState({ isLoading: false })
                }
            }
        )
    }

    /**
    * On check card payment success
    */
    onCheckCardPaymentSuccess = (onSuccess) => {
        if (onSuccess.status == RESPONSE_SUCCESS) {
            if (onSuccess.stripe_response.error !== undefined && onSuccess.stripe_response.error.message !== undefined) {
                showValidationAlert(strings("paymentFail") + "\n\n" + onSuccess.stripe_response.error.message)
                this.setState({ isLoading: false })

            }
            else if (onSuccess.stripe_response.status == "succeeded") {
                debugLog("Payment Sucessful with 3d secure authentication ::::::")
                this.setState({ isLoading: true, })
                this.txn_id = onSuccess.stripe_response.id;

                this.placeOrder(onSuccess.stripe_response.id, "stripe")
            }
            else {
                debugLog("PAYMENT FAILED ::::")
                showValidationAlert(strings("paymentFail"));
                this.setState({ isLoading: false })
            }
        } else {
            this.setState({ isLoading: false })
            showValidationAlert(strings("paymentFail"));
        }
    }
    /**
     * On check card payment failure
     */
    onCheckCardPaymentFailure = (onFailure) => {
        debugLog("FAILURE :::::", onFailure)
        showValidationAlert((strings("paymentFail") + "\n\n" + (
            onFailure.stripe_response !== undefined &&
                onFailure.stripe_response.error !== undefined ? onFailure.stripe_response.error.message : "")));
        this.setState({ isLoading: false })
    }
    onWebViewCloseHandler = () => {
        showPaymentDialogue(
            strings('cancelConfirm'),
            [{
                text: strings('dialogYes'), onPress: () => {
                    this.setState({ url: undefined })
                }
            },
            { text: strings('dialogNo'), onPress: () => { }, isNotPreferred: true }],
            strings('warning'),
        );

    }


    //#region ADD TO CART API
    /**
     * 
     * @param {Success Response Object } onSuccess 
     */
    onSuccessAddCart = (onSuccess) => {
        debugLog("ADD TO CART :::::", onSuccess)
        if (onSuccess.error != undefined) {
            showValidationAlert(
                onSuccess.error.message != undefined
                    ? onSuccess.error.message
                    : strings("generalWebServiceError")
            );
        } else {
            if (onSuccess.status == RESPONSE_SUCCESS) {
                this.updatedCartResponse = onSuccess
                this.checkoutDetail.subtotal = onSuccess.subtotal
                this.checkoutDetail.total = onSuccess.total
                this.checkoutDetail.is_creditcard = this.addToCartData.is_creditcard
                this.checkoutDetail.is_creditcard_fee_applied = onSuccess.is_creditcard_fee_applied
                this.checkoutDetail.creditcard_feeval = onSuccess.creditcard_feeval
                this.checkoutDetail.creditcard_fee_typeval = onSuccess.creditcard_fee_typeval
                // this.checkoutDetail.coupon_array = JSON.stringify(this.updatedCartResponse.coupon_arrayapply)

                // this.promoCode = onSuccess.coupon_name
                // this.promoObj = onSuccess
                // if (onSuccess.coupon_arrayapply !== undefined && onSuccess.coupon_arrayapply !== null && onSuccess.coupon_arrayapply.length !== 0)
                //     this.setState({ discountedPrice: onSuccess.total })
                // else
                //     this.setState({ discountedPrice: undefined })
                if (this.state.totalPendingAmount !== 0 && this.state.selectedOption == "paylater")
                    this.setState({ payPending: false, later: true, disableToggle: false })

                this.old_credit_fee = 0

                if (this.addToCartData.is_creditcard == "yes" && this.oldSubtotal !== undefined && this.oldSubtotal !== null && this.oldSubtotal !== "") {
                    if
                        (onSuccess.creditcard_fee_typeval == "Amount") { }
                    else
                        if (onSuccess.creditcard_fee_typeval == "Percentage") {
                            this.old_credit_fee = Number(this.oldSubtotal) * (Number(onSuccess.creditcard_feeval) / 100)
                        }
                }

                this.setState({ totalPrice: parseFloat(onSuccess.total) + (this.state.selectedOption == "paylater" ? 0 : parseFloat(this.state.totalPendingAmount)) })
            }

        }

        if (this.promoArray.length !== 0) {
            this.applyPromo()
        }

        this.setState({ isLoading: false });
    }

    /**
     * 
     * @param {Failure REsponse Object} onFailure 
     */
    onFailureAddCart = (onFailure) => {
        showValidationAlert(
            onFailure.message != undefined
                ? onFailure.message
                : strings("generalWebServiceError")
        );
        // if (onFailure.status == COUPON_ERROR) {
        //     this.promoArray = []
        // }
        this.setState({ isLoading: false });
    }

    /**
     * 
     * @param { Item to be added to Cart } items 
     */
    getCartData = () => {

        netStatus(status => {
            if (status) {
                this.setState({ isLoading: true });


                let objAddToCart = this.addToCartData
                objAddToCart.items = JSON.parse(this.addToCartData.items)
                // objAddToCart.coupon_array = this.promoArray,

                addToCart(objAddToCart, this.onSuccessAddCart, this.onFailureAddCart, this.props);
            } else {
                showValidationAlert(strings("noInternet"));
            }
        });
    }

    render3DVerificationModal = () => {
        return (
            <EDPopupView isModalVisible={this.state.url !== undefined}
                shouldDismissModalOnBackButton
                onRequestClose={this.onWebViewCloseHandler}>
                <View style={{ margin: 20, marginVertical: 80, borderRadius: 16, flex: 1, overflow: "hidden", backgroundColor: EDColors.white }}>
                    <WebView
                        onLoad={() => this.setState({ isLoading: false })}
                        // onLoadStart={() => this.setState({ isLoading: false })}
                        style={{ width: "100%", height: "100%", borderRadius: 16, }}
                        source={{ uri: this.state.url }}
                        javaScriptEnabled={true}
                        startInLoadingState
                        renderLoading={() => { return <Spinner size="small" color={EDColors.primary} /> }}
                        allowsBackForwardNavigationGestures={true}
                        onNavigationStateChange={this.navigationChange}
                    />
                </View>
            </EDPopupView>
        )
    }

    // RENDER METHOD
    render() {
        return (
            <BaseContainer
                title={strings("paymentTitle")}
                left={isRTLCheck() ? 'arrow-forward' : 'arrow-back'}
                right={[]}
                onLeft={this.onBackEventHandler}
                loading={this.state.isLoading || this.state.isSavedCardLoading || this.state.isPaymentLoading || this.state.promoLoading}
            >

                {this.render3DVerificationModal()}

                {/* Navigation Events */}
                <NavigationEvents onWillFocus={this.onWillFocusPayment} />

                <KeyboardAwareScrollView
                    pointerEvents={this.state.isLoading || this.state.isSavedCardLoading || this.state.isPaymentLoading || this.state.promoLoading ? 'none' : 'auto'}
                    enableResetScrollToCoords={true}
                    resetScrollToCoords={{ x: 0, y: 0 }}
                    style={{ flex: 1 }}
                    bounces={false}
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="always"
                    behavior="padding"
                    enabled>
                    {/* MAIN VIEW */}
                    <View style={style.mainView}>
                        <View>

                            {this.state.pendingOrderArray !== undefined && this.state.pendingOrderArray.length !== 0 ?
                                <View style={style.pendingContainer}>
                                    <View style={[style.pendingSubContainer, { flexDirection: isRTLCheck() ? "row-reverse" : "row" }]}>
                                        <Text style={style.simpleText} onPress={this.togglePending}>
                                            {this.state.payPending ? strings("payPending") : strings("pendingOrderMsg")}
                                        </Text>
                                    </View>
                                    <View style={[{ marginTop: 10, flexDirection: isRTLCheck() ? "row-reverse" : "row" }]}>
                                        <Text style={[style.pendingText]}>
                                            {
                                                strings("pendingAmount")}
                                        </Text>
                                        <Text style={style.currencyStyle}>
                                            {this.props.currency + funGetFrench_Curr(this.state.totalPendingAmount, 1, this.props.currency)}
                                        </Text>

                                    </View>
                                    <EDRTLView style={style.checkBoxStyle} >
                                        <EDRTLView style={style.centerView}>
                                            <Icon name={this.state.payPending ? "check-box" : "check-box-outline-blank"} color={EDColors.primary} size={getProportionalFontSize(23)} onPress={this.togglePending} />
                                            <Text style={style.checkboxText} >
                                                {strings("addtoBill")}
                                            </Text>
                                        </EDRTLView>
                                        <Text onPress={this.navigateToPendingOrders} style={style.textStyle} >
                                            {strings("viewDetails")}
                                        </Text>
                                    </EDRTLView>
                                </View> : null}

                            {this.paymentOptions !== undefined && this.paymentOptions !== null && this.paymentOptions.length !== 0 ?
                                <EDRTLView style={style.methodStyle}>
                                    <Text style={style.methodText}>
                                        {strings("choosePaymentOption")}
                                    </Text>
                                </EDRTLView> : null}
                            {this.paymentOptions !== undefined && this.paymentOptions !== null && this.paymentOptions.length !== 0 ?

                                <FlatList
                                    data={this.paymentOptions}
                                    extraData={this.state}
                                    renderItem={this.createPaymentList}
                                /> : null}

                            {/* <View style={{ marginHorizontal: 10, marginBottom: 20, marginTop: 20 }}>
                                <EDRTLText style={style.titleText} title={strings("addCookingInstruction")} />
                                <EDRTLView style={style.footerStyle}>
                                    <Icon name={"edit"} type={"feather"} color={EDColors.black} size={getProportionalFontSize(20)} style={style.editIconStyle} />
                                    <TextInput
                                        style={{
                                            textAlign: isRTLCheck() ? 'right' : 'left',
                                            flexDirection: isRTLCheck() ? 'row-reverse' : 'row',
                                            fontFamily: EDFonts.medium,
                                            marginHorizontal: 10, flex: 1, marginVertical: 20, color: EDColors.grayNew
                                        }}
                                        placeholder={strings("bringCutlery")}
                                        value={this.state.strComment}
                                        onChangeText={this.onTextChangeHandler}
                                    />
                                </EDRTLView>
                            </View> */}
                        </View>


                    </View>
                </KeyboardAwareScrollView>

                <View>
                    {!this.state.later && this.state.order_delivery == "DineIn" ?
                        <View style={style.promoResponseView}>
                            {/* {this.promoCode !== undefined && this.promoCode !== null && this.promoCode.trim().length !== 0 ?
                                <Text style={style.promoText}>
                                    {strings("getDiscount") + this.props.currency + funGetFrench_Curr(this.promoObj.coupon_discount, 1, this.props.currency)}
                                </Text>
                                : null
                            }
                            <View style={style.promoResponseView} >
                                {this.promoCode !== undefined && this.promoCode !== null && this.promoCode.trim().length !== 0 ? (
                                    <View style={style.promoResponse} >
                                        <Text style={[style.promoResponseTextStyle, { flex: 1 }]} >
                                            {this.promoCode + " " + strings("promoApplied")}
                                        </Text>
                                        <TouchableOpacity
                                            style={{ alignSelf: "center", marginRight: 10 }}
                                            onPress={this.removeCoupon}>
                                            <Icon
                                                name={"close"}
                                                size={getProportionalFontSize(28)}
                                                color={EDColors.black}
                                            />
                                        </TouchableOpacity>
                                    </View>) : (
                                    (this.props.userID != undefined && this.props.userID != "") ?
                                        <EDRTLView style={style.discountView}>
                                            <SvgXml xml={discount_icon} style={style.iconStyle} />
                                            <Text
                                                style={style.promoCode}
                                                onPress={this.navigateToPromoCode}>
                                                {strings("haveAPromo")}
                                            </Text>
                                        </EDRTLView>
                                        : null)}
                            </View> */}


                            {this.promoObj !== undefined &&
                                this.promoObj !== null &&
                                this.promoObj.coupon_arrayapply !== undefined &&
                                this.promoObj.coupon_arrayapply !== null &&
                                this.promoObj.coupon_arrayapply.length !== 0

                                ? (
                                    <>
                                        <View style={style.cartResponse} >
                                            <EDRTLView style={{ alignItems: 'center', marginVertical: 10 }}>
                                                <Text style={[style.cartResponseTextStyle, { flex: 1 }]} >
                                                    {this.promoObj.coupon_arrayapply.length + strings("couponApplied")}
                                                </Text>
                                                <Icon //TEMP
                                                    // onPress={this.clearPromo}
                                                    onPress={this.removeCoupon}
                                                    name={"close"}
                                                    size={getProportionalFontSize(26)}
                                                    color={EDColors.black}
                                                />
                                            </EDRTLView>

                                        </View>
                                        <View style={{ height: 1, backgroundColor: EDColors.separatorColorNew, width: "95%", alignSelf: 'center' }} />
                                        <EDRTLView style={style.discountView}>
                                            {/* <Icon name={"local-offer"} size={16} color={EDColors.blackSecondary} style={style.discountIcon} /> */}
                                            <SvgXml xml={discount_icon} style={{ marginHorizontal: 5 }} />
                                            <Text
                                                style={style.promoCode}
                                                onPress={this.navigateToPromoCode}>
                                                {strings("applyMore")}
                                            </Text>
                                        </EDRTLView>
                                    </>
                                ) : (

                                    <EDRTLView style={style.discountView}>
                                        {/* <Icon name={"local-offer"} size={16} color={EDColors.blackSecondary} style={style.discountIcon} /> */}
                                        <SvgXml xml={discount_icon} style={{ marginHorizontal: 5 }} />
                                        <Text
                                            style={style.promoCode}
                                            onPress={this.navigateToPromoCode}>
                                            {strings("haveAPromo")}
                                        </Text>
                                    </EDRTLView>
                                )}
                        </View>
                        :
                        null
                    }

                </View>
                <EDThemeButton
                    isLoadingPermission={this.state.isLoading || this.state.isPaymentLoading || this.state.promoLoading || this.state.isSavedCardLoading}

                    label={isRTLCheck() ? strings("continue") + "- " + funGetFrench_Curr(((this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPrice) + this.old_credit_fee), 1, this.props.currency) + this.props.currency : strings("continue") + "- " + this.props.currency + funGetFrench_Curr(((this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPrice) + this.old_credit_fee), 1, this.props.currency)}
                    style={style.checkOutContainer}
                    textStyle={style.button}
                    onPress={this.onContinuePressedEventhandler}
                />

            </BaseContainer >
        );
    }
    //#endregion

    /** NAVIGATE TO PROMO CODE CONTAINER */
    navigateToPromoCode = () => {
        // debugLog("TYPE OF ::::", typeof this.checkoutDetail.subtotal, typeof this.oldSubtotal, this.oldSubtotal, this.checkoutDetail.subtotal)
        this.props.navigation.navigate("PromoCodeContainer", {
            getData: this.getPromo,
            subTotal: this.checkoutDetail.subtotal + Number(this.oldSubtotal),
            resId: this.checkoutDetail.restaurant_id,
            order_delivery: "DineIn",
            promoArray: this.promoArray,
            used_coupons: this.promoObj.coupon_arrayapply,

        });
    }
    //#endregion

    getPromo = data => {
        this.promoArray = data
        this.promoCode = data;
        // this.applyPromo()
        // this.getCartData()
    }

    clearPromo = () => {
        this.promoArray = []

        this.getCartData()

    }

    //Apply promo
    applyPromo = () => {

        netStatus(status => {
            if (status) {
                this.setState({ promoLoading: true })
                let promoParams = {
                    user_id: this.props.userID,
                    // token: this.props.token,
                    coupon_array: JSON.stringify(this.promoArray),
                    order_delivery: "DineIn",
                    total: this.checkoutDetail.total + Number(this.oldSubtotal) + Number(this.old_credit_fee),
                    subtotal: this.checkoutDetail.subtotal + Number(this.oldSubtotal),
                    language_slug: this.props.lan,
                    restaurant_id: this.resContentId
                }
                debugLog("APPLY PROMO :::::", promoParams)
                applyCouponAPI(promoParams, this.onSuccessApplyCoupon, this.onFailureApplyCoupon, this.props)
            }
            else
                showNoInternetAlert()
        })
    }

    onSuccessApplyCoupon = onSuccess => {
        debugLog("On success coupon :::::", onSuccess)
        if (onSuccess.status == RESPONSE_SUCCESS || onSuccess.status == COUPON_ERROR) {
            this.promoCode = onSuccess.coupon_name
            this.promoObj = onSuccess

            this.setState({ discountedPrice: Number(this.oldSubtotal) + this.updatedCartResponse.total - onSuccess.coupon_discount })
            if (onSuccess.status == COUPON_ERROR)
                showValidationAlert(onSuccess.message)
        }
        else
            showValidationAlert(onSuccess.message)
        this.setState({ promoLoading: false })
    }

    onFailureApplyCoupon = onFailure => {
        this.setState({ promoLoading: false })
        showValidationAlert(strings("generalWebServiceError"))
        debugLog("On failure coupon :::::", onFailure)
    }

    removeCoupon = () => {
        this.promoCode = undefined
        this.promoObj = {}
        this.promoArray = []
        this.setState({ discountedPrice: undefined })


    }

    //#region 
    onTextChangeHandler = (value) => {
        this.setState({ strComment: value })
    }
    //#endregion

    //#region 
    /** CONTINUE PRESSED EVENT */
    onContinuePressedEventhandler = () => {

        if (this.state.selectedOption == "stripe" && (this.state.defaultCard == undefined || this.state.showCardInput)) {

            if (!this.validateCard())
                return;
        }

        this.checkoutDetail.extra_comment = this.state.strComment

        if (this.state.order_delivery == "DineIn") {
            this.checkoutDetail.coupon_id = this.promoObj.coupon_id,
                this.checkoutDetail.coupon_discount = this.promoObj.coupon_discount,
                this.checkoutDetail.coupon_name = this.promoObj.coupon_name,
                this.checkoutDetail.coupon_amount = this.promoObj.coupon_amount,
                this.checkoutDetail.coupon_type = this.promoObj.coupon_type
            if (this.promoCode !== undefined)
                this.checkoutDetail.total = this.promoObj.total

        }
        this.checkoutDetail.order_date = Moment(new Date().toLocaleString('en-US', {
            timeZone: RNLocalize.getTimeZone()
        })).format("DD-MM-YYYY hh:mm A");

        debugLog("date 24", this.state.later, this.state.cashOn);
        if (this.state.later) {
            this.checkoutDetail.payment_option = "paylater"
            this.placeOrder();
        }
        else if (this.state.cashOn) {
            this.checkoutDetail.payment_option = "cod"
            this.placeOrder()
        }
        else {

            if (this.state.selectedOption == "stripe") {
                let pendingTotalAmount = this.state.discountedPrice !== undefined
                    ? this.state.discountedPrice : this.state.totalPendingAmount

                let final_total =
                    this.state.payPending && this.promoObj.coupon_arrayapply == undefined ?
                        parseFloat(this.checkoutDetail.total) + parseFloat(pendingTotalAmount) : this.checkoutDetail.total.toFixed(2).toString()
                // this.checkoutDetail.payment_option = "stripe"
                // this.props.saveCheckoutDetails(this.checkoutDetail)
                // this.props.navigation.navigate("StripePaymentContainer", {
                //     "currency_code": this.currecy_code,
                //     isPendingAdded: this.state.payPending,
                //     pendingTotalPayment: (this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPendingAmount),
                //     // pendingTotal: (this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPendingAmount),
                //     order_id: this.oldOrderID,
                //     promoObj: this.promoObj
                // })
                this.startStripePayment(final_total)
            }


          
            else if (this.state.selectedOption == "paypal") {
                this.checkoutDetail.payment_option = "paypal"
                this.props.saveCheckoutDetails(this.checkoutDetail)
                this.props.navigation.navigate("PaymentGatewayContainer", {
                    "currency_code": this.currecy_code,
                    isPendingAdded: this.state.payPending,
                    pendingTotalPayment: ((this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPrice) + this.old_credit_fee),
                    order_id: this.oldOrderID,
                    promoObj: this.promoObj,
                    creditcard_feeval: this.checkoutDetail.creditcard_feeval,
                    creditcard_fee_typeval: this.checkoutDetail.creditcard_fee_typeval
                })
            }
            else {
                if (this.paymentOptions !== undefined && this.paymentOptions !== null && this.paymentOptions.length !== 0)
                    showValidationAlert(strings("choosePaymentError"))
                else
                    showValidationAlert(strings("noPaymentMethods"))
            }
        }
    }
    //#endregion

    //#region 
    onBackEventHandler = () => {
        this.props.navigation.goBack();
    }
    //#endregion

   

    /**
   * Start Stripe Payment
   */
    startStripePayment = () => {
        debugLog("CARD DATA :::::", this.cardData)
        netStatus(
            status => {
                if (status) {
                    var params = {}
                    this.setState({ isLoading: true })
                    if (this.cardData !== undefined) {
                        params = {
                            language_slug: this.props.lan,
                            exp_month: this.cardData.values.expiry.substring(0, 2),
                            exp_year: this.cardData.values.expiry.substring(3, 5),
                            card_number: this.cardData.values.number,
                            cvc: this.cardData.values.cvc,
                            amount: ((this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPrice) + this.old_credit_fee) * 100,
                            // amount: parseFloat(this.checkoutDetail.total),
                            currency: this.currecy_code,
                            user_id: this.props.userID,
                            payment_method: 'stripe',
                            save_card_flag: this.state.isCardSave ? 1 : 0,
                            is_default_card: this.noCards || this.state.isDefaultCard ? 1 : 0,
                            country_code: this.state.countryCode || (this.selectedCountry !== undefined ? this.selectedCountry.cca2 : ''),
                            zipcode: this.cardData.values.postalCode,
                            isLoggedIn: this.props.userID !== undefined && this.props.userID !== null && this.props.userID !== "" ? 1 : 0
                        }
                    }
                    else if (this.state.defaultCard !== undefined) {
                        params = {
                            language_slug: this.props.lan,
                            amount: ((this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPrice) + this.old_credit_fee) * 100,
                            currency: this.currecy_code,
                            payment_method: 'stripe',
                            user_id: this.props.userID,
                            payment_method_id: this.state.defaultCard.id,
                            isLoggedIn: 1
                        }
                    }
                    else {
                        this.setState({ isLoading: false })
                        showValidationAlert(strings("generalWebServiceError"))
                        return;
                    }
                    createPaymentMethod(params, this.onPaymentMethodSuccess, this.onPaymentMethodFailure, this.props)
                }
                else {
                    showNoInternetAlert();
                }
            }
        )
    }
    /**
     * On payment method success
     */
    onPaymentMethodSuccess = (onSuccess) => {
        debugLog("ONSUCCESS::::::::", onSuccess)
        if (onSuccess.status == RESPONSE_SUCCESS) {
            if (onSuccess.stripe_response.error !== undefined) {
                showValidationAlert(((onSuccess.message !== undefined ? onSuccess.message : strings("paymentFail")) + "\n\n" + onSuccess.stripe_response.error.message))
                this.setState({ isLoading: false })

            }
            else if (onSuccess.stripe_response.status == "succeeded") {
                debugLog("Payment Sucessful without 3d secure authentication ::::::")
                this.txn_id = onSuccess.stripe_response.id;
                this.placeOrder(onSuccess.stripe_response.id, "stripe")
                this.setState({ isLoading: false })
            }
            else if (onSuccess.stripe_response.next_action.redirect_to_url.url !== undefined) {
                debugLog("Redirecting for 3d secure authentication ::::::")
                this.txn_id = onSuccess.stripe_response.id;
                this.setState({ url: onSuccess.stripe_response.next_action.redirect_to_url.url, isLoading: false })
            }
        } else {
            this.setState({ isLoading: false })
            showDialogue(onSuccess.message, [], '', () => { })
        }
    }
    /**
     * On payment method failure
     */
    onPaymentMethodFailure = (onFailure) => {
        debugLog("FAILURE :::::", onFailure)
        showValidationAlert(strings("paymentFail"))


        this.setState({ isLoading: false })

    }

    updatePendingOrders = () => {
        netStatus(status => {
            if (status) {
                let param = {
                    user_id: parseInt(this.props.userID) || 0,
                    // token: this.props.token,
                    language_slug: this.props.lan,
                    order_id: this.oldOrderID,
                    total_rate: ((this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPrice) + this.old_credit_fee),
                    coupon_id: this.promoObj.coupon_id,
                    coupon_discount: this.promoObj.coupon_discount,
                    coupon_name: this.promoObj.coupon_name,
                    coupon_amount: this.promoObj.coupon_amount,
                    coupon_type: this.promoObj.coupon_type,
                    payment_option: this.tempPayment_option !== undefined && this.tempPayment_option !== null && this.tempPayment_option !== "" ? this.tempPayment_option : "cod",
                    transaction_id: this.txn_id,

                    coupon_array: JSON.stringify(this.promoObj.coupon_arrayapply),


                }
                if (this.tempPayment_option == "razorpay") {
                    param.razorpay_payment_id = this.razorpay_payment_id
                    param.merchant_order_id = this.merchant_order_id
                }
                if (this.addToCartData.is_creditcard == "yes") {
                    param.creditcard_feeval = this.checkoutDetail.creditcard_feeval
                    param.creditcard_fee_typeval = this.checkoutDetail.creditcard_fee_typeval

                }
                this.setState({ isLoading: true });
                updatePendingOrdersAPI(param, this.onSuccessUpdateOrder, this.onFailureUpdateOrder, this.props)
            } else {
                this.setState({ isLoading: false });
                showValidationAlert(strings("noInternet"));
            }
        });
    }
    onSuccessUpdateOrder = onSuccess => {
        if (onSuccess.status == RESPONSE_SUCCESS) {
            this.setState({ isLoading: false });
            if (this.state.order_delivery == "DineIn") {
                this.props.saveTableID(undefined);
                this.props.saveResID(undefined);
            }
            this.props.navigation.popToTop();
            this.props.navigation.navigate("OrderConfirm", { isForDineIn: this.state.order_delivery == "DineIn" ? true : false, resObj: this.resObj, navigateToOrder: true, cashback: onSuccess.earned_wallet_money });
        }
        else {
            this.setState({ isLoading: false });
            showValidationAlert(onSuccess.message)
        }
    }
    onFailureUpdateOrder = (onfailure) => {
        this.setState({ isLoading: false });
        showValidationAlert(strings("generalWebServiceError"))
    }

    //#region ADD ORDER
    /**
     * @param { Success Reponse Object } onSuccess
     */
    onSuccessAddOrder = (onSuccess) => {
        if (onSuccess.error != undefined) {
            showValidationAlert(
                onSuccess.error.message != undefined
                    ? onSuccess.error.message
                    : strings("generalWebServiceError")
            );
        } else {
            if (onSuccess.status == RESPONSE_SUCCESS) {
                this.props.saveCartCount(0);
                this.props.saveWalletMoney(onSuccess.wallet_money)

                clearCartData(
                    response => {

                        if (this.state.payPending) {
                            this.updatePendingOrders();
                        }
                        else {
                            if (this.state.order_delivery == "DineIn" && !this.state.later) {
                                this.props.saveTableID(undefined);
                                this.props.saveResID(undefined);
                            }
                            this.props.navigation.popToTop();
                            this.props.navigation.navigate("OrderConfirm", { isForDineIn: this.state.order_delivery == "DineIn" ? true : false, resObj: onSuccess.restaurant_detail, navigateToOrder: !this.state.later, cashback: onSuccess.earned_wallet_money });
                        }

                        // if (this.state.cashOn) {
                        //     this.props.navigation.popToTop();
                        //     this.props.navigation.navigate("OrderConfirm", { currecy_code: this.props.currency, cashback: onSuccess.earned_wallet_money });
                        // } else {
                        //     this.props.navigation.navigate("PaymentGatewayContainer", { "currency_code": this.currecy_code, order_id: onSuccess.order_id })
                        // }
                    },
                    error => { }
                );
            }

            else if (onSuccess.status == RESTAURANT_ERROR) {
                this.props.saveCartCount(0);
                clearCurrency_Symbol(onSuccess => { }, onfailure => { })
                clearCartData(
                    response => {
                    },
                    error => { }
                );
                showDialogue(onSuccess.message, [], strings("appName"),
                    () =>
                        this.props.navigation.dispatch(
                            StackActions.reset({
                                index: 0,
                                actions: [
                                    NavigationActions.navigate({ routeName: isRTLCheck() ? "MainContainer_Right" : "MainContainer" })
                                ]
                            })
                        ));
            }
            else {
                showValidationAlert(onSuccess.message);
            }
        }
        this.setState({ isLoading: false });
    }
    //#endregion

    /**
     * @param { Failure Response Object } onFailure
     */
    onFailureAddOrder = (onfailure) => {
        showValidationAlert(strings("generalWebServiceError"));
        this.setState({ isLoading: false });
    }

    //#region 
    /** PLACE ORDER API */
    placeOrder = (txn_id, payment_option = '') => {
        netStatus(status => {
            // this.checkoutDetail.extra_comment = this.state.strComment

            if (this.oldOrderID !== undefined)
                this.checkoutDetail.order_id = this.oldOrderID

            let params = {
                ...this.checkoutDetail,
                isLoggedIn: (this.props.userID !== undefined && this.props.userID !== null && this.props.userID !== "") ? 1 : 0,
                phone_number: this.props.phoneNumber,
                first_name: this.props.firstName,
                last_name: this.props.lastName,
                email: this.props.email,
                phone_code: this.props.phoneCode

            }
            this.tempPayment_option = ""

            if (payment_option == "razorpay") {
                params.transaction_id = this.razorpay_payment_id;
                params.payment_option = payment_option
                params.razorpay_payment_id = this.razorpay_payment_id
                params.merchant_order_id = this.merchant_order_id
            }

            else if (txn_id !== undefined && txn_id !== null) {
                params.transaction_id = txn_id;
                params.payment_option = payment_option
                this.tempPayment_option = payment_option
            }
            console.log("CheckOut request :::::::::: ", JSON.stringify(params))
            // return;
            if (status) {
                this.setState({ isLoading: true });
                addOrder(params, this.onSuccessAddOrder, this.onFailureAddOrder, this.props, true)
            } else {
                showValidationAlert(strings("noInternet"));
            }
        });
    }
    //#endregion
}

export const style = StyleSheet.create({
    subContainer: {
        margin: 10,
        backgroundColor: "#fff",
        borderRadius: 16,
        padding: 10,
        paddingHorizontal: 15,
        marginHorizontal: 15

    },
    titleText: {
        color: EDColors.black,
        fontSize: getProportionalFontSize(15),
        fontFamily: EDFonts.semiBold,
        marginHorizontal: 10,
        flex: 1,
    },
    editIconStyle: { marginHorizontal: 15 },
    footerStyle: { marginTop: 20, marginHorizontal: 10, backgroundColor: EDColors.white, borderWidth: 2, borderColor: EDColors.separatorColorNew, borderRadius: 16, alignItems: "center" },
    totalPrice: {
        flex: 1,
        fontFamily: EDFonts.medium,
        fontSize: getProportionalFontSize(14),
        alignSelf: "center",
        marginHorizontal: 10,
        color: EDColors.white
    },
    centerView: { alignItems: 'center' },
    simpleText: {
        fontFamily: EDFonts.medium,
        fontSize: getProportionalFontSize(14),
        color: EDColors.blackSecondary
    },
    checkboxText: {
        fontFamily: EDFonts.medium,
        fontSize: getProportionalFontSize(14),
        color: EDColors.blackSecondary,
        marginHorizontal: 5
    },
    currencyStyle: {
        fontFamily: EDColors.medium,
        fontSize: getProportionalFontSize(14),
        color: EDColors.nonVeg
    },
    textStyle: {
        fontFamily: EDFonts.semiBold,
        fontSize: getProportionalFontSize(12),
        color: EDColors.black
    },
    checkOutContainer: {
        borderRadius: 16,
        backgroundColor: EDColors.primary,
        justifyContent: 'center',
        alignItems: 'center',
        width: '90%',
        height: metrics.screenHeight * 0.07,
        marginHorizontal: 10,
        marginBottom: 8
    },
    paymentMethodTitle: {
        // flex: 1,
        fontFamily: EDFonts.medium,
        fontSize: getProportionalFontSize(14),
        color: "#000000",
        margin: 10
    },
    iconStyle: {
        marginHorizontal: 5
    },
    button: {
        paddingTop: 10,
        paddingRight: 20,
        paddingLeft: 20,
        paddingBottom: 10,
        color: "#fff",
        fontFamily: EDFonts.medium,
        fontSize: getProportionalFontSize(16)
    },
    pendingContainer: {
        borderRadius: 16,
        padding: 15,
        backgroundColor: EDColors.white,
        margin: 10,
        marginBottom: 10,
    },
    pendingSubContainer: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },
    checkBoxStyle: {
        alignItems: "center",
        justifyContent: "space-between",
        borderTopColor: EDColors.radioSelected,
        borderTopWidth: 1,
        paddingTop: 10,
        marginTop: 10
    },
    pendingText: {
        fontFamily: EDFonts.medium,
        fontSize: getProportionalFontSize(14),
        color: EDColors.black,
        // flex: 1
    },
    promoResponseView: {
        borderRadius: 16,
        marginLeft: 15,
        marginRight: 15,
        backgroundColor: "#fff",
        // marginVertical: 5,
        paddingVertical: 5
    },
    promoResponse: {
        flexDirection: "row",
        alignItems: "center",
        padding: 5,
    },
    promoResponseTextStyle: {
        // flex: 1,
        fontFamily: EDFonts.regular,
        fontSize: getProportionalFontSize(16),
        alignSelf: "center",
        color: EDColors.black,
        textAlign: "center",
        marginHorizontal: 10,
        height: 20
    },
    promoText: {
        marginHorizontal: 10,
        color: "green",
        fontSize: getProportionalFontSize(14),
        textAlign: 'center',
        fontFamily: EDFonts.medium,
        marginBottom: 5
    },
    methodStyle: { marginHorizontal: 15, marginTop: 15 },
    methodText: { fontFamily: EDFonts.semiBold, fontSize: getProportionalFontSize(16), color: EDColors.black },
    discountView: { justifyContent: 'center', alignItems: 'center', paddingVertical: 10 },
    promoCode: {
        alignSelf: "center",
        color: EDColors.black,
        fontFamily: EDFonts.regular,
        fontSize: 15,
    },
    mainView: { flex: 1, justifyContent: "space-between" },
    cardView: {
        alignItems: "center",
        justifyContent: "space-between",
        flex: 1,
        borderTopColor: EDColors.separatorColorNew,
        borderTopWidth: 1,
        paddingTop: 15,
        marginTop: 5,
        paddingHorizontal: 10
    },
    cardSubView: {
        alignItems: "center",
        flex: 1,

    },
    last4Text: {
        fontFamily: EDFonts.medium,
        fontSize: getProportionalFontSize(14),
        color: EDColors.black
    },
    expiredText: {
        fontFamily: EDFonts.regular,
        fontSize: getProportionalFontSize(13),
        color: EDColors.mastercard
    },
    changeCard: {
        fontFamily: EDFonts.semiBold,
        fontSize: getProportionalFontSize(13),
        color: EDColors.primary,
        // flex: 1,
        textAlign: "right",
        textDecorationLine: "underline",
        marginLeft: 10
    },
    cartResponseTextStyle: {
        // flex: 1,
        fontFamily: EDFonts.regular,
        fontSize: getProportionalFontSize(16),
        alignSelf: "center",
        color: EDColors.black,
        textAlign: "center",
        marginHorizontal: 10,
        height: 22,
        marginVertical: 4,
    }
});

export default connect(
    state => {
        return {
            checkoutDetail: state.checkoutReducer.checkoutDetail,
            lan: state.userOperations.lan,
            currency: state.checkoutReducer.currency_symbol,
            email: state.userOperations.email,
            firstName: state.userOperations.firstName,
            phoneNumber: state.userOperations.phoneNumberInRedux,
            userID: state.userOperations.userIdInRedux,
            token: state.userOperations.phoneNumberInRedux,
            lastName: state.userOperations.lastName,
            phoneCode: state.userOperations.phoneCode,
            email: state.userOperations.email,
            guestDetails: state.checkoutReducer.guestDetails,

        };
    },
    dispatch => {
        return {
            saveCheckoutDetails: checkoutData => {
                dispatch(saveCheckoutDetails(checkoutData));
            },
            saveCartCount: data => {
                dispatch(saveCartCount(data));
            },
            saveWalletMoney: token => {
                dispatch(saveWalletMoneyInRedux(token))
            },
            saveTableID: table_id => {
                dispatch(saveTableIDInRedux(table_id))
            },
            saveResID: table_id => {
                dispatch(saveResIDInRedux(table_id))
            }
        };
    }
)(PaymentContainer);