import React from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet, FlatList, ScrollView, BackHandler, RefreshControl, Platform } from "react-native";
import BaseContainer from "./BaseContainer";
import { EDColors } from "../utils/EDColors";
import { RESPONSE_SUCCESS, funGetDateStr, capiString, debugLog, funGetFrench_Curr, getProportionalFontSize, isRTLCheck, CARD_BRANDS, RETURN_URL } from "../utils/EDConstants";
import { getPayLaterOrdersAPI, updatePendingOrdersAPI, applyCouponAPI, getPaymentList, getSavedCardsAPI, checkCardPayment, createPaymentMethod } from "../utils/ServiceManager";
import { showDialogue, showDialogueNew, showNoInternetAlert, showPaymentDialogue, showValidationAlert } from "../utils/EDAlert";
import PriceDetail from "../components/PriceDetail";
import metrics from "../utils/metrics";
import { connect } from "react-redux";
import { saveNavigationSelection } from "../redux/actions/Navigation";
import { netStatus } from "../utils/NetworkStatusConnection";
import { NavigationEvents } from "react-navigation";
import { strings } from "../locales/i18n";
import EDPlaceholderComponent from "../components/EDPlaceholderComponent";
import { EDFonts } from "../utils/EDFontConstants";
import EDRTLText from "../components/EDRTLText";
import EDRTLView from "../components/EDRTLView";
import { Icon } from "react-native-elements";
import EDButton from "../components/EDButton";
import { saveTableIDInRedux, saveResIDInRedux } from "../redux/actions/User";
import { SvgXml } from "react-native-svg";
import { discount_icon } from "../utils/EDSvgIcons";
import EDImage from "../components/EDImage";
import { CreditCardInput } from "react-native-credit-card-input";
import Assets from "../assets";
import WebView from "react-native-webview";
import EDPopupView from "../components/EDPopupView";
import { Spinner } from "native-base";

class PendingOrderContainer extends React.Component {
    //#region LIFE CYCLE METHODS

    constructor(props) {
        super(props);
        this.refreshing = false
        this.checkoutDetail = this.props.checkoutDetail;
        this.strOnScreenMessageInProcess = '';
        this.strOnScreenSubtitleinProcess = '';
        this.strOnScreenMessagePast = '';
        this.strOnScreenSubtitlePast = '';
        this.arrayUpcoming = [];
        this.receievedOrders = this.props.navigation.state !== undefined && this.props.navigation.state.params !== undefined && this.props.navigation.state.params.orderDetails !== undefined ? this.props.navigation.state.params.orderDetails : []
        this.currency_symbol = ""
        this.promoObj = {}
        this.used_coupons = []
        this.promoArray = []
        this.possible_creditcard_fee = 0
    }

    state = {
        isLoading: false,
        restaurant_id: "",
        totalPendingAmount: 0,
        online: true,
        paymentModal: false,
        discountedPrice: undefined,
        selectedOption: "",
        restaurant_id: '',
        showCardInput: false,
        isDefaultCard: false,
        noDefaultCard: false,
        defaultCard: undefined,
        isSavedCardLoading: false,
        isCardSave: false,
        url: undefined,
        countryCode: undefined,
        cardError: "",


    };

    componentWillReceiveProps = newProps => {
        if (this.props.screenProps.isRefresh !== newProps.screenProps.isRefresh) {
            this.networkConnectivityStatus()
        }
    }

    componentWillMount() {


    }

    async componentDidMount() {
        // this.checkUser()
        if (this.props.userID !== undefined && this.props.userID !== null && this.props.userID !== "") {
            this.networkConnectivityStatus()
        } else {
            showDialogueNew(strings("loginValidation"), [], strings("appName"), () => {
                this.props.navigation.navigate("LoginContainer", {
                    isCheckout: true
                });
            });
        }
        this.props.saveNavigationSelection("PendingOrders");

    }

    getPaymentOptionsAPI = () => {
        netStatus(isConnected => {
            if (isConnected) {
                this.setState({ isLoading: true })

                var params = {
                    language_slug: this.props.lan,
                    user_id: this.props.userID,
                    is_dine_in: '1',
                    restaurant_id: this.state.restaurant_id,
                    isLoggedIn: (this.props.userID !== undefined && this.props.userID !== null && this.props.userID !== "") ? 1 : 0
                }

                getPaymentList(params, this.onSuccessPaymentList, this.onFailurePaymentList, this.props)
            } else {
                showNoInternetAlert()
            }
        })
    }

    onSuccessPaymentList = onSuccess => {
        if (onSuccess.Payment_method !== undefined && onSuccess.Payment_method !== null && onSuccess.Payment_method.length !== 0) {
            this.paymentOptions = onSuccess.Payment_method

            //FETCH SAVED CARDS IN STRIPE PAYMENT IF SUPPORTED
            if (this.props.userID !== undefined && this.props.userID !== null && this.paymentOptions.map(data =>
                data.payment_gateway_slug
            ).includes("stripe"))
                this.fetchCards()

            if (onSuccess.Payment_method[0].payment_gateway_slug == "razorpay") {
                this.razorpayDetails = onSuccess.Payment_method[0]
            }

            if (this.state.selectedOption !== "stripe")
                this.setState({ selectedOption: onSuccess.Payment_method[0].payment_gateway_slug })
            this.forceUpdate();
        }
        this.setState({ isLoading: false })

    }

    onFailurePaymentList = onFailure => {
        console.log('::::::::::: PAYMENT FALURE', onFailure)
        showValidationAlert(onFailure.message)
        this.setState({ isLoading: false })
    }

    myValidatePostalCode(postalCode) {
        return postalCode.match(/^\d{5,6}$/) ? "valid" :
            postalCode.length > 6 ? "invalid" :
                "incomplete";
    }

    /**
   * On Credit card input
   */
    onCCInput = (data) => {
        this.isCardError = false
        this.isExpiryError = false
        this.isCVCError = false
        this.isCountryError = false
        this.isPostalError = false

        this.setState({ cardError: "" })
        this.cardData = data
    }

    validateCard = () => {
        if (this.cardData !== undefined) {
            if (this.cardData.status.number == "valid") {
                if (this.cardData.status.expiry == "valid") {
                    if (this.isForEditing || this.cardData.status.cvc == "valid") {
                        if (this.selectedCountry !== undefined || this.state.countryCode !== undefined) {
                            if (this.cardData.status.postalCode == "valid") {
                                this.isCardError = false
                                this.isExpiryError = false
                                this.isCVCError = false
                                this.isCountryError = false
                                this.isPostalError = false
                                this.setState({ cardError: "" })

                            }
                            else {
                                this.isPostalError = true
                                this.setState({ cardError: strings("invalidPostal") })
                            }
                        }
                        else {
                            this.isCountryError = true
                            this.setState({ cardError: strings("noCountry") })
                        }
                    }
                    else {
                        this.isCVCError = true
                        console.log("Invalid CVC")
                        this.setState({ cardError: strings("invalidCVC") })
                    }
                }
                else {
                    this.isExpiryError = true
                    console.log("Invalid expiry date", this.state.cardError)
                    this.setState({ cardError: strings("invalidExpiry") })
                }
            }
            else {
                this.isCardError = true
                console.log("Invalid card number")
                this.setState({ cardError: this.cardData.values.number == '' ? strings("nocardData") : strings("invalidCard") })
            }
        }
        else {
            this.isCardError = true
            this.setState({ cardError: strings("nocardData") })
        }

        return this.isCardError === false &&
            this.isExpiryError === false &&
            this.isCVCError === false &&
            this.isCountryError === false &&
            this.isPostalError === false;
    }


    fetchCards = () => {
        this.state.defaultCard = undefined
        this.state.noDefaultCard = false
        netStatus(status => {
            if (status) {
                this.setState({ isSavedCardLoading: true })
                let userParams = {
                    language_slug: this.props.lan,
                    user_id: this.props.userID,
                    isLoggedIn: 1
                }
                getSavedCardsAPI(userParams, this.onSuccessFetchCards, this.onFailureFetchCards, this.props)
            }
            else {
                this.setState({ isSavedCardLoading: false });
            }
        })
    }

    onSuccessFetchCards = onSuccess => {
        this.noCards = false

        if (onSuccess.stripe_response !== undefined &&
            onSuccess.stripe_response !== null &&
            onSuccess.stripe_response.length !== 0
        ) {

            let valid_cards = []
            valid_cards = onSuccess.stripe_response.filter(cardData => { return new Date() < new Date().setFullYear(cardData.card.exp_year, cardData.card.exp_month, 1) })
            this.setState({
                noDefaultCard: !(valid_cards !== undefined && valid_cards !== null && valid_cards.length !== 0 && valid_cards[0].is_default_card == "1"),
                showCardInput: false,
                defaultCard: valid_cards !== undefined && valid_cards !== null && valid_cards.length !== 0 && valid_cards[0].is_default_card == "1" ? valid_cards[0] : undefined
            })
        }
        else {
            debugLog("NO CARDS ::::::")
            this.noCards = true

        }

        this.setState({ isSavedCardLoading: false });
    }

    onFailureFetchCards = onFailure => {
        this.setState({ isSavedCardLoading: false });
    }



    /**
   * Start Stripe Payment
   */
    startStripePayment = (final_total) => {
        debugLog("CARD DATA :::::", this.cardData)
        netStatus(
            status => {
                if (status) {
                    var params = {}
                    this.setState({ isLoading: true })
                    if (this.cardData !== undefined) {
                        params = {
                            language_slug: this.props.lan,
                            exp_month: this.cardData.values.expiry.substring(0, 2),
                            exp_year: this.cardData.values.expiry.substring(3, 5),
                            card_number: this.cardData.values.number,
                            cvc: this.cardData.values.cvc,
                            amount: final_total * 100,
                            // amount: parseFloat(this.checkoutDetail.total),
                            currency: this.arrayUpcoming[0].currency_code,
                            user_id: this.props.userID,
                            payment_method: 'stripe',
                            save_card_flag: this.state.isCardSave ? 1 : 0,
                            is_default_card: this.noCards || this.state.isDefaultCard ? 1 : 0,
                            country_code: this.state.countryCode || (this.selectedCountry !== undefined ? this.selectedCountry.cca2 : ''),
                            zipcode: this.cardData.values.postalCode,
                            isLoggedIn: this.props.userID !== undefined && this.props.userID !== null && this.props.userID !== "" ? 1 : 0
                        }
                    }
                    else if (this.state.defaultCard !== undefined) {
                        params = {
                            language_slug: this.props.lan,
                            amount: final_total * 100,
                            currency: this.arrayUpcoming[0].currency_code,
                            payment_method: 'stripe',
                            user_id: this.props.userID,
                            payment_method_id: this.state.defaultCard.id,
                            isLoggedIn: 1
                        }
                    }
                    else {
                        this.setState({ isLoading: false })
                        showValidationAlert(strings("generalWebServiceError"))
                        return;
                    }
                    createPaymentMethod(params, this.onPaymentMethodSuccess, this.onPaymentMethodFailure, this.props)
                }
                else {
                    showNoInternetAlert();
                }
            }
        )
    }
    /**
     * On payment method success
     */
    onPaymentMethodSuccess = (onSuccess) => {
        debugLog("ONSUCCESS::::::::", onSuccess)
        if (onSuccess.status == RESPONSE_SUCCESS) {
            if (onSuccess.stripe_response.error !== undefined) {
                showValidationAlert(((onSuccess.message !== undefined ? onSuccess.message : strings("paymentFail")) + "\n\n" + onSuccess.stripe_response.error.message))
                this.setState({ isLoading: false })

            }
            else if (onSuccess.stripe_response.status == "succeeded") {
                debugLog("Payment Sucessful without 3d secure authentication ::::::")
                this.txn_id = onSuccess.stripe_response.id;
                // this.placeOrder(onSuccess.stripe_response.id, "stripe")
                this.updatePendingOrders(this.txn_id, "stripe")
                this.setState({ isLoading: false })
            }
            else if (onSuccess.stripe_response.next_action.redirect_to_url.url !== undefined) {
                debugLog("Redirecting for 3d secure authentication ::::::")
                this.txn_id = onSuccess.stripe_response.id;
                this.setState({ url: onSuccess.stripe_response.next_action.redirect_to_url.url, isLoading: false })
            }
        } else {
            this.setState({ isLoading: false })
            showDialogue(onSuccess.message, [], '', () => { })
        }
    }
    /**
     * On payment method failure
     */
    onPaymentMethodFailure = (onFailure) => {
        debugLog("FAILURE :::::", onFailure)
        showValidationAlert(strings("paymentFail"))

        this.setState({ isLoading: false })

    }


    onOptionSelection = (data) => {


        this.setState({ selectedOption: data.payment_gateway_slug })
        if (data.payment_gateway_slug == "razorpay") {
            this.razorpayDetails = data
        }
        // this.forceUpdate()
    }
    createPaymentList = item => {

        let display_name = `display_name_${this.props.lan}`
        return (

            <View>
                <TouchableOpacity style={[styles.paymentBtn]}
                    activeOpacity={1}
                    onPress={() => this.onOptionSelection(item.item)}>
                    <EDRTLView>
                        <EDRTLView style={{ alignItems: 'center', flex: 1 }}>

                            <Icon name={
                                item.item.payment_gateway_slug === 'applepay' ? 'apple-pay'
                                    :
                                    item.item.payment_gateway_slug === 'paypal' ? 'paypal' : item.item.payment_gateway_slug === 'cod' ? 'account-balance-wallet' : 'credit-card'}
                                type={
                                    item.item.payment_gateway_slug === 'applepay' ? 'fontisto' :
                                        item.item.payment_gateway_slug === 'paypal' ? 'entypo' : item.item.payment_gateway_slug === 'cod' ? 'material' : 'material'}
                                size={20} color={this.state.selectedOption == item.item.payment_gateway_slug ? EDColors.primary : EDColors.text}
                                style={styles.paymentIconStyle} />

                            <EDRTLText style={[styles.paymentMethodTitle, { color: this.state.selectedOption == item.item.payment_gateway_slug ? EDColors.black : EDColors.blackSecondary }]} title={
                                item.item[display_name]} />
                        </EDRTLView>
                        <Icon name={"check"} size={getProportionalFontSize(16)} selectionColor={EDColors.primary} color={this.state.selectedOption == item.item.payment_gateway_slug ? EDColors.primary : EDColors.white} style={{ margin: 10 }} />
                    </EDRTLView>
                    {this.state.selectedOption == "stripe" && item.item.payment_gateway_slug == "stripe" ?
                        <>
                            {!this.state.showCardInput ?
                                this.state.defaultCard !== undefined ?
                                    <>
                                        <EDRTLView style={[styles.cardView]}>
                                            <EDRTLView style={styles.cardSubView}>
                                                <Icon
                                                    name={this.state.defaultCard.card.brand == CARD_BRANDS.visa ? "cc-visa" :
                                                        this.state.defaultCard.card.brand == CARD_BRANDS.mastercard ? "cc-mastercard" :
                                                            this.state.defaultCard.card.brand == CARD_BRANDS.amex ? "cc-amex" : "credit-card"
                                                    }
                                                    color={this.state.defaultCard.card.brand == CARD_BRANDS.visa ? EDColors.visa :
                                                        this.state.defaultCard.card.brand == CARD_BRANDS.mastercard ? EDColors.mastercard :
                                                            this.state.defaultCard.card.brand == CARD_BRANDS.amex ? EDColors.amex : EDColors.primary
                                                    }
                                                    size={20}
                                                    type="font-awesome"
                                                />
                                                <View style={{ marginHorizontal: 20, flex: 1 }}>
                                                    <EDRTLView style={{ alignItems: 'center' }}>
                                                        <Text style={{ color: EDColors.black }}>•••• </Text>
                                                        <EDRTLText title={this.state.defaultCard.card.last4} style={styles.last4Text} />
                                                    </EDRTLView>
                                                    {(new Date().setFullYear(this.state.defaultCard.card.exp_year, this.state.defaultCard.card.exp_month, 1) < new Date()) ?
                                                        <EDRTLText title={strings("expired")} style={styles.expiredText} /> : null}
                                                </View>
                                                <EDRTLText title={strings("change")} style={styles.changeCard} onPress={this.changeCard} />
                                                <EDRTLText title={
                                                    strings("homeNew")} style={styles.changeCard} onPress={this.addCard} />

                                            </EDRTLView>
                                        </EDRTLView>
                                        <EDRTLText title={strings("defaultCard")} style={{ fontFamily: EDFonts.regular, color: EDColors.textNew, marginHorizontal: 7.5, flex: 1, fontSize: getProportionalFontSize(14), marginTop: 10 }} />

                                    </> :

                                    this.state.isLoading || this.state.isPaymentLoading || this.state.isSavedCardLoading ? null :
                                        <>
                                            <EDRTLText title={
                                                this.noCards ?
                                                    strings("noCards") :
                                                    strings("noDefaultCard")} style={{ fontFamily: EDFonts.regular, color: EDColors.error, marginHorizontal: 7.5, flex: 1, fontSize: getProportionalFontSize(14), marginTop: 10 }} />
                                            <EDRTLView style={{ alignItems: 'center', marginTop: 10, }}>
                                                {this.noCards ? null :
                                                    <EDRTLText title={strings("setNow")} style={[styles.changeCard, { marginLeft: 7.5 }]} onPress={this.changeCard} />}
                                                <EDRTLText title={strings("homeNew")} style={styles.changeCard} onPress={this.addCard} />
                                            </EDRTLView>
                                        </>


                                : null}
                            {this.state.showCardInput ?
                                < View style={{}}>
                                    {this.state.defaultCard !== undefined || this.state.noDefaultCard ?
                                        <EDRTLText title={
                                            strings("dialogCancel")} style={[styles.changeCard, { textAlign: 'left', marginLeft: 0 }]} onPress={this.addCard} /> : null}
                                    <CreditCardInput
                                        ref={ref => this.creditcardRef = ref}
                                        autoFocus={false}
                                        onChange={this.onCCInput}
                                        cardFontFamily={EDFonts.regular}
                                        cardImageFront={Assets.card_front}
                                        cardImageBack={Assets.card_back}
                                        errorMessage={this.state.cardError}
                                        isCardError={this.isCardError}
                                        isExpiryError={this.isExpiryError}
                                        isCVCError={this.isCVCError}
                                        isPostalError={this.isPostalError}
                                        isCountryError={this.isCountryError}
                                        onCountrySelect={this.onStripeCountrySelect}
                                        requiresPostalCode
                                        requiresCVC={true}
                                        // requiresCountry={this.order_delivery == "Delivery"}
                                        requiresCountry={true}
                                        dialCode={this.state.countryCode}
                                        isReadOnly={false}
                                        validatePostalCode={this.myValidatePostalCode}
                                        countryData={this.props.countryArray}
                                        cvcStyle={{ width: metrics.screenWidth / 2 - 50, marginLeft: 15 }}
                                        expiryStyle={{ width: metrics.screenWidth / 2 - 50 }}
                                        errorLeftPadding={metrics.screenWidth / 2 - 35}
                                    />
                                    {this.props.userID !== undefined && this.props.userID !== null && this.props.userID !== "" ?
                                        <TouchableOpacity onPress={this.toggleCardSave} activeOpacity={1}>
                                            <EDRTLView style={{ alignItems: 'center', marginTop: 10 }}>
                                                <Icon name={this.state.isCardSave ? "check-square-o" : "square-o"}
                                                    color={EDColors.primary}
                                                    size={20}
                                                    type="font-awesome"
                                                />
                                                <EDRTLText title={strings("askSaveCard")} style={{ fontFamily: EDFonts.medium, color: EDColors.black, marginHorizontal: 7.5, flex: 1, fontSize: getProportionalFontSize(14) }} />
                                            </EDRTLView>
                                        </TouchableOpacity> : null}

                                    {this.props.userID !== undefined && this.props.userID !== null && this.props.userID !== "" && this.state.isCardSave && !this.noCards ?
                                        <TouchableOpacity onPress={this.toggleCardDefault} activeOpacity={1}>
                                            <EDRTLView style={{ alignItems: 'center', marginTop: 10 }}>
                                                <Icon name={this.state.isDefaultCard ? "check-square-o" : "square-o"}
                                                    color={EDColors.primary}
                                                    size={20}
                                                    type="font-awesome"
                                                />
                                                <EDRTLText title={strings("setDefaultCard")} style={{ fontFamily: EDFonts.medium, color: EDColors.black, marginHorizontal: 7.5, flex: 1, fontSize: getProportionalFontSize(14) }} />
                                            </EDRTLView>
                                        </TouchableOpacity> : null}
                                </View> : null}</>

                        : null}
                </TouchableOpacity>
            </View >
        )
    }


    onStripeCountrySelect = country => {
        this.isCountryError = false
        this.selectedCountry = country
        debugLog("COUNTRY :::::", country)
        this.setState({ cardError: '', countryCode: undefined })
    }


    toggleCardSave = () => {
        this.setState({ isCardSave: !this.state.isCardSave, isDefaultCard: false })
    }

    toggleCardDefault = () => {
        this.setState({ isDefaultCard: !this.state.isDefaultCard })
    }

    changeCard = () => {
        this.props.navigation.push('savedCards', { isForAddressList: true, });

    }

    addCard = () => {
        this.setState({ showCardInput: !this.state.showCardInput })
    }

    refreshDefaultCard = (card) => {
        this.setState({ defaultCard: card })
    }



    // getIconName=(iconName)=>{
    //     if(iconName === 'paypal')

    // }
    //#region 
    /** NETWORK CONNECTIVITY */
    networkConnectivityStatus = () => {
        if (this.receievedOrders !== undefined && this.receievedOrders !== null && this.receievedOrders.length !== 0) {
            this.arrayUpcoming = this.receievedOrders
            this.updateData(this.receievedOrders)
            this.getPaymentOptionsAPI()
        }
        else
            this.getPendingOrderData();
    }
    //#endregion

    //#region ON BLUR EVENT
    onDidFocusContainer = () => {

        if (this.receievedOrders !== undefined && this.receievedOrders !== null && this.receievedOrders.length !== 0) {
            BackHandler.addEventListener('hardwareBackPress', this.onBackPressed);
            this.arrayUpcoming = this.receievedOrders
            this.updateData(this.receievedOrders)
        }
        else
            this.checkUser()
        this.props.saveNavigationSelection("PendingOrders");
    }


    componentWillUnmount = () => {
        BackHandler.removeEventListener('hardwareBackPress', this.onBackPressed)
    }

    onBackPressed = () => {
        this.props.navigation.goBack();
        return true;
    }
    //#endregion

    //#region 
    /** ON LEFT PRESSED */
    onBackPressedEvent = () => {
        if (this.receievedOrders.length !== 0)
            this.props.navigation.goBack();
        else
            this.props.navigation.openDrawer();

    }
    //#endregion

    navigateToPaymentGateway = () => {
        if (this.state.selectedOption == "paypal")
            this.props.navigation.navigate("PaymentGatewayContainer",
                {
                    isPending: true,
                    pendingTotal: (this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPendingAmount) + (this.state.selectedOption == "cod" ? 0 : Number(this.possible_creditcard_fee)),
                    currency_code: this.arrayUpcoming[0].currency_code,
                    promoObj: this.promoObj,
                    order_id: this.arrayUpcoming[0].order_id,
                    creditcard_feeval: this.creditcard_details.creditcard_feeval,
                    creditcard_fee_typeval: this.creditcard_details.creditcard_fee_typeval

                })
        else if (this.state.selectedOption == "stripe") {
            // this.props.navigation.navigate("StripePaymentContainer",
            //     {
            //         isPending: true,
            //         pendingTotal: (this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPendingAmount),
            //         currency_code: this.arrayUpcoming[0].currency_code,
            //         promoObj: this.promoObj,
            //         order_id: this.arrayUpcoming[0].order_id
            //     })
            let pendingTotalAmount = this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPendingAmount

            this.startStripePayment(pendingTotalAmount + (this.state.selectedOption == "cod" ? 0 : Number(this.possible_creditcard_fee)))
        }

       


    }

    

    startPayment = () => {

        if (this.state.selectedOption == "stripe" && (this.state.defaultCard == undefined || this.state.showCardInput)) {

            if (!this.validateCard())
                return;
        }

        this.setState({ paymentModal: false })
        if (this.state.selectedOption !== "") {
            if (this.state.selectedOption == "cod")
                this.updatePendingOrders()
            else
                this.navigateToPaymentGateway()
        }
        else
            showValidationAlert(strings("choosePaymentError"))
    }

    updatePendingOrders = (txn_id = "", payment_option = "cod") => {
        netStatus(status => {
            if (status) {
                let pendingTotalAmount = this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPendingAmount
                let param = {
                    user_id: parseInt(this.props.userID) || 0,
                    // token: this.props.token,
                    language_slug: this.props.lan,
                    order_id: this.arrayUpcoming[0].order_id,
                    total_rate: Number(pendingTotalAmount) + Number(this.possible_creditcard_fee),
                    coupon_id: this.promoObj.coupon_id,
                    coupon_discount: this.promoObj.coupon_discount,
                    coupon_name: this.promoObj.coupon_name,
                    coupon_amount: this.promoObj.coupon_amount,
                    coupon_type: this.promoObj.coupon_type,
                    payment_option: payment_option,
                    coupon_array: JSON.stringify(this.promoObj.coupon_arrayapply)
                }
                if (payment_option == "razorpay") {
                    param.razorpay_payment_id = this.razorpay_payment_id
                    param.merchant_order_id = this.merchant_order_id
                    param.transaction_id = txn_id

                }
                else if (txn_id !== '')
                    param.transaction_id = txn_id

                if (payment_option !== "cod") {
                    param.creditcard_feeval = this.creditcard_details ? this.creditcard_details.creditcard_feeval : ""
                    param.creditcard_fee_typeval = this.creditcard_details ? this.creditcard_details.creditcard_fee_typeval : ""
                }
                this.setState({ isLoading: true });
                updatePendingOrdersAPI(param, this.onSuccessUpdateOrder, this.onFailureUpdateOrder, this.props)
            } else {
                this.setState({ isLoading: false });
                showValidationAlert(strings("noInternet"));
            }
        });
    }
    onSuccessUpdateOrder = onSuccess => {
        if (onSuccess.status == RESPONSE_SUCCESS) {
            this.setState({ isLoading: false });
            showDialogueNew(this.txn_id !== undefined && this.txn_id !== null && this.txn_id !== "" ? strings("payPendingSuccess") : strings("payPendingSuccessCod"), [], strings("appName"), () => {
                this.props.navigation.popToTop();
                this.props.navigation.navigate("Home");
            });
        }
        else {
            this.setState({ isLoading: false });
            showValidationAlert(onSuccess.message)
        }
    }
    onFailureUpdateOrder = (onfailure) => {
        this.setState({ isLoading: false });
        showValidationAlert(strings("generalWebServiceError"))
    }

    //Apply promo

    applyPromo = data => {
        debugLog("APPLY PROMO :::::", data)
        this.promoArray = data
        netStatus(status => {
            if (status) {
                this.setState({ isLoading: true })
                let promoParams = {
                    user_id: this.props.userID,
                    // token: this.props.token,
                    // coupon: data,
                    order_delivery: "DineIn",
                    total: this.arrayUpcoming[0].price.filter(data => data.label_key === "Total")[0].value,
                    subtotal: this.arrayUpcoming[0].price.filter(data => data.label_key === "Sub Total")[0].value,
                    language_slug: this.props.lan,
                    coupon_array: JSON.stringify(this.promoArray),
                    // restaurant_id: this.state.restaurant_id,
                    restaurant_id: this.arrayUpcoming[0].restaurant_content_id
                }

                if (this.arrayUpcoming[0].price.map(data => data.label_key).includes("Wallet Discount")) {
                    promoParams['wallet_amount'] = this.arrayUpcoming[0].price.filter(data => data.label_key === "Wallet Discount")[0].value
                }

                applyCouponAPI(promoParams, this.onSuccessApplyCoupon, this.onFailureApplyCoupon, this.props)
            }
            else
                showNoInternetAlert()
        })
    }

    onSuccessApplyCoupon = onSuccess => {
        this.setState({ isLoading: false })
        debugLog("On success coupon :::::", onSuccess)
        if (onSuccess.status == RESPONSE_SUCCESS) {
            this.prmoApplied = true
            this.promoObj = onSuccess
            this.setState({ discountedPrice: onSuccess.total_rate })
            // showValidationAlert(onSuccess.message)
        }
        else
            showValidationAlert(onSuccess.message)
    }

    onFailureApplyCoupon = onFailure => {
        this.setState({ isLoading: false })
        this.promoArray = []
        showValidationAlert(strings("generalWebServiceError"))
        debugLog("On failure coupon :::::", onFailure)
    }

    removeCoupon = () => {
        this.setState({ discountedPrice: undefined })

        this.prmoApplied = false
        this.promoObj = {}
        this.promoArray = []

    }


    /** NAVIGATE TO PROMO CODE CONTAINER */
    navigateToPromoCode = () => {
        this.setState({ paymentModal: false })
        this.props.navigation.navigate("PromoCodeFromSideBar", {
            getData: this.applyPromo,
            subTotal: this.arrayUpcoming[0].price.filter(data => data.label_key === "Sub Total")[0].value,
            resId: this.arrayUpcoming[0].restaurant_id,
            order_delivery: "DineIn",
            used_coupons:
                this.promoObj !== undefined && this.promoObj !== null ?
                    this.promoObj.coupon_arrayapply : [],
            promoArray: this.promoArray,

        });
    }
    //#endregion




    // Go to restaurant
    goToRestaurant = () => {
        this.props.saveTableID(this.arrayUpcoming[0].table_id);
        this.props.saveResID(this.arrayUpcoming[0].restaurant_id);
        this.props.navigation.navigate("RestaurantContainer", {
            restId: this.arrayUpcoming[0].restaurant_id,
            content_id: this.arrayUpcoming[0].restaurant_content_id,
            currency: this.arrayUpcoming[0].currency_symbol
        }
        );
    }

    onPullToRefreshHandler = () => {
        this.strOnScreenMessageInProcess = ""
        this.checkUser()
    }


    /**
    * Webview Navigation change
    */
    navigationChange = (resp) => {
        // debugLog("NAVIGATION CHANGE CALLED :::::::::::", resp)
        if (resp.url.includes(RETURN_URL + "/?payment_intent")) {
            this.setState({ url: undefined })
            this.checkCardPayment()
        }
    }

    checkCardPayment = () => {
        netStatus(
            status => {
                if (status) {
                    this.setState({ isLoading: true })
                    var params = {
                        trans_id: this.txn_id,
                        language_slug: this.props.lan
                    }
                    checkCardPayment(params, this.onCheckCardPaymentSuccess, this.onCheckCardPaymentFailure, this.props)
                }
                else {
                    showNoInternetAlert();
                    this.setState({ isLoading: false })
                }
            }
        )
    }

    /**
    * On check card payment success
    */
    onCheckCardPaymentSuccess = (onSuccess) => {
        if (onSuccess.status == RESPONSE_SUCCESS) {
            if (onSuccess.stripe_response.error !== undefined && onSuccess.stripe_response.error.message !== undefined) {
                showValidationAlert(strings("paymentFail") + "\n\n" + onSuccess.stripe_response.error.message)
                this.setState({ isLoading: false })

            }
            else if (onSuccess.stripe_response.status == "succeeded") {
                debugLog("Payment Sucessful with 3d secure authentication ::::::")
                this.setState({ isLoading: true, })
                this.txn_id = onSuccess.stripe_response.id;
                this.updatePendingOrders(this.txn_id, "stripe")
                // this.placeOrder(onSuccess.stripe_response.id, "stripe")
            }
            else {
                debugLog("PAYMENT FAILED ::::")
                showValidationAlert(strings("paymentFail"));
                this.setState({ isLoading: false })
            }
        } else {
            this.setState({ isLoading: false })
            showValidationAlert(strings("paymentFail"));
        }
    }
    /**
     * On check card payment failure
     */
    onCheckCardPaymentFailure = (onFailure) => {
        debugLog("FAILURE :::::", onFailure)
        showValidationAlert((strings("paymentFail") + "\n\n" + (
            onFailure.stripe_response !== undefined &&
                onFailure.stripe_response.error !== undefined ? onFailure.stripe_response.error.message : "")));
        this.setState({ isLoading: false })
    }
    onWebViewCloseHandler = () => {
        showPaymentDialogue(
            strings('cancelConfirm'),
            [{
                text: strings('dialogYes'), onPress: () => {
                    this.setState({ url: undefined })
                }
            },
            { text: strings('dialogNo'), onPress: () => { }, isNotPreferred: true }],
            strings('warning'),
        );

    }

    render3DVerificationModal = () => {
        return (
            <EDPopupView isModalVisible={this.state.url !== undefined}
                shouldDismissModalOnBackButton
                onRequestClose={this.onWebViewCloseHandler}>
                <View style={{ margin: 20, marginVertical: 80, borderRadius: 16, flex: 1, overflow: "hidden", backgroundColor: EDColors.white }}>
                    <WebView
                        onLoad={() => this.setState({ isLoading: false })}
                        // onLoadStart={() => this.setState({ isLoading: false })}
                        style={{ width: "100%", height: "100%", borderRadius: 16, }}
                        source={{ uri: this.state.url }}
                        javaScriptEnabled={true}
                        startInLoadingState
                        renderLoading={() => { return <Spinner size="small" color={EDColors.primary} /> }}
                        allowsBackForwardNavigationGestures={true}
                        onNavigationStateChange={this.navigationChange}
                    />
                </View>
            </EDPopupView>
        )
    }


    // RENDER METHOD
    render() {
        // debugLog("PROPS IN PENDIGN ::::", this.props.navigation)
        return (
            <BaseContainer
                title={strings("activeDineInOrder")}
                left={
                    this.props.navigation.state !== undefined && this.props.navigation.state.params !== undefined && this.props.navigation.state.params.orderDetails !== undefined ?
                        (isRTLCheck() ? 'arrow-forward' : 'arrow-back') : "menu"}
                right={[]}
                onLeft={this.onBackPressedEvent}
                onConnectionChangeHandler={this.networkConnectivityStatus}
                loading={this.state.isLoading}
            >

                {this.render3DVerificationModal()}

                {/* FOCUS EVENTS */}
                <NavigationEvents onDidFocus={this.onDidFocusContainer} />



                {/* MAIN VIEW */}
                <View style={styles.mainContainer}>

                    <View style={styles.orderParentView}>
                        {console.log("ARRAY UPCOMING ::::::", this.arrayUpcoming)}
                        {this.arrayUpcoming != undefined && this.arrayUpcoming != null && this.arrayUpcoming.length > 0 ? (
                            <View style={{ flex: 1 }}>
                                <ScrollView
                                    style={{ flex: 1 }}
                                    showsVerticalScrollIndicator={false}
                                    refreshControl={
                                        <RefreshControl
                                            refreshing={this.refreshing || false}
                                            colors={[EDColors.primary]}
                                            onRefresh={this.onPullToRefreshHandler}
                                        />}
                                >

                                    {this.renderPendingOrder(this.arrayUpcoming[0])}
                                    {/* </ScrollView> */}
                                    {this.receievedOrders !== undefined && this.receievedOrders !== null && this.receievedOrders.length !== 0 ?
                                        null : <>
                                            {this.arrayUpcoming[0].order_status.toLowerCase() !== "complete" && this.arrayUpcoming[0].order_status.toLowerCase() !== 'delivered' ?

                                                <EDRTLView style={{ marginHorizontal: 10 }}>
                                                    <TouchableOpacity
                                                        onPress={this.goToRestaurant}
                                                        style={[styles.BtnStyle, {
                                                            flexDirection: isRTLCheck() ? 'row-reverse' : 'row',
                                                        }]}
                                                    >
                                                        <Text style={styles.btnText} >
                                                            {strings("orderMore")}
                                                        </Text>
                                                        <Icon
                                                            name={isRTLCheck() ? "leftcircleo" : "rightcircleo"}
                                                            type={'ant-design'}
                                                            size={getProportionalFontSize(15)}
                                                            color={EDColors.white}
                                                        />
                                                    </TouchableOpacity>
                                                </EDRTLView>
                                                : null}
                                            <View style={styles.promoView} >
                                                {this.prmoApplied == true ? (


                                                    <>

                                                        <View style={styles.promoResponse} >
                                                            <View style={{ flex: 1, alignItems: 'center' }}>
                                                                <EDRTLView>
                                                                    <Text style={[styles.promoResponseTextStyle, { flex: 1 }]} >
                                                                        {this.promoObj.coupon_arrayapply.length + strings("couponApplied")}
                                                                    </Text>
                                                                    <TouchableOpacity
                                                                        style={styles.coupenBtn}
                                                                        onPress={this.removeCoupon}>
                                                                        <Icon
                                                                            name={"close"}
                                                                            size={getProportionalFontSize(28)}
                                                                            color={EDColors.black}
                                                                        />
                                                                    </TouchableOpacity>
                                                                </EDRTLView>
                                                                <EDRTLView style={styles.discountView}>
                                                                    <SvgXml xml={discount_icon} />
                                                                    <Text
                                                                        style={styles.promoCode}
                                                                        onPress={this.navigateToPromoCode}>
                                                                        {strings("applyMore")}
                                                                    </Text>
                                                                </EDRTLView>
                                                            </View>
                                                        </View>
                                                    </>
                                                ) : (
                                                    (this.props.userID != undefined && this.props.userID != "") ?
                                                        <EDRTLView style={styles.discountView}>
                                                            <SvgXml xml={discount_icon} />
                                                            <Text
                                                                style={styles.promoCode}
                                                                onPress={this.navigateToPromoCode}>
                                                                {strings("haveAPromo")}
                                                            </Text>
                                                        </EDRTLView>
                                                        : null)}
                                            </View>


                                            <View >
                                                {this.paymentOptions !== undefined && this.paymentOptions !== null && this.paymentOptions.length !== 0 ?
                                                    <EDRTLView style={styles.methodStyle}>
                                                        <Text style={styles.methodText}>
                                                            {strings("choosePaymentOption")}
                                                        </Text>
                                                    </EDRTLView>
                                                    : null}
                                                <EDRTLView style={styles.subContainer}>

                                                    {this.paymentOptions !== undefined && this.paymentOptions !== null && this.paymentOptions.length !== 0 ?
                                                        <FlatList
                                                            data={this.paymentOptions}
                                                            extraData={this.state}
                                                            renderItem={this.createPaymentList}
                                                        /> : null}
                                                </EDRTLView>
                                                <EDButton label={strings("payNow")}
                                                    style={styles.btnView}
                                                    onPress={this.startPayment}

                                                    numberOfLines={2}
                                                />

                                            </View>
                                        </>
                                    }
                                </ScrollView>
                            </View>
                        )
                            :
                            (this.strOnScreenMessageInProcess || '').trim().length > 0 ? (
                                <ScrollView
                                    style={{ flex: 1 }}
                                    contentContainerStyle={{ flex: 1, justifyContent: "center" }}
                                    refreshControl={
                                        <RefreshControl
                                            refreshing={this.refreshing || false}
                                            colors={[EDColors.primary]}
                                            onRefresh={this.onPullToRefreshHandler}
                                        />}
                                >
                                    <EDPlaceholderComponent
                                        // title={this.strOnScreenMessageInProcess}
                                        title={this.strOnScreenMessageInProcess}
                                    />
                                </ScrollView>
                            ) : null}
                    </View>
                </View>
            </BaseContainer>
        );
    }
    //#endregion

    renderPendingOrder = (data) => {
        let coupon_arrayapply = [{
            coupon_name: "TEST"
        },
        {
            coupon_name: "TEST2"
        }
        ]
        return (
            <TouchableOpacity style={styles.pendingContainer}
                activeOpacity={1}
            >
                <View style={styles.pendingSubContainer}>
                    <EDRTLView style={styles.pendingSubView}>
                        <View style={{ justifyContent: 'space-evenly', flex: 2.5 }}>
                            <View>
                                <EDRTLText style={styles.pastOrderText}
                                    title={funGetDateStr(data.order_date, "MMMM DD,YYYY, hh:mm A")} />
                            </View>
                            <View style={styles.topView}>
                                <EDRTLText style={styles.nameText} title={data.restaurant_name} />
                            </View>
                            <EDRTLView style={styles.topView}>
                                <Text style={styles.statusTextString}>{strings("orderStatus2") + ": "}</Text>
                                <Text style={styles.statusText}>{data.order_status_display}</Text>
                            </EDRTLView>
                            {data.table_number !== null && data.table_number !== undefined ?
                                <EDRTLView style={styles.topView} >
                                    <Text style={styles.statusTextString}>{strings("tableNo") + ": "}</Text>
                                    <Text style={styles.statusText}>{isRTLCheck() ? (data.table_number) : (+ data.table_number)}</Text>
                                </EDRTLView> : null}

                        </View>
                        <View style={{ flex: 1 }} >
                            {/* <Image source={Assets.user_placeholder} style={styles.pendingIcon} /> */}
                            <EDImage style={styles.pendingIcon}
                                source={data.restaurant_image}
                                resizeMode="cover"

                            />
                        </View>
                    </EDRTLView>

                    <View style={styles.detailView} >
                        <EDRTLView>
                            <Text style={styles.titleText}> {strings('orderDetails') + " (#" + data.order_id + ")"} </Text>
                        </EDRTLView>
                        <FlatList
                            style={styles.priceListStyle}
                            contentContainerStyle={styles.listStyle}
                            showsVerticalScrollIndicator={false}
                            data={data.items}
                            listKey={(item, index) => "D" + index.toString()}
                            renderItem={({ item, index }) => {
                                return (
                                    <>
                                        <EDRTLView style={styles.textStylePrice}>
                                            <EDRTLText title={capiString(item.name) + (Number(item.quantity > 1) ? " (x" + item.quantity + ")" : "")} style={styles.itemTextStyle} />
                                            <EDRTLText style={styles.itemTextStyle} title={data.currency_symbol + funGetFrench_Curr(item.itemTotal, 1, data.currency_symbol)} />
                                        </EDRTLView>

                                        {(item.is_customize == 1 || item.is_customize == "1") && item.addons_category_list !== undefined && item.addons_category_list !== null ?
                                            item.addons_category_list.map(
                                                category => {
                                                    return (
                                                        <View style={styles.addonView}>

                                                            {category.addons_list.map(
                                                                addons => {
                                                                    return (
                                                                        <EDRTLView style={[{ marginVertical: 3, justifyContent: "space-between" }, isRTLCheck() ? { marginLeft: 5 } : { marginRight: 5 }]}>
                                                                            <EDRTLText style={styles.addonItemText} title={capiString(addons.add_ons_name) + (Number(item.quantity > 1) ? " (x" + item.quantity + ")" : "")} />
                                                                            <EDRTLText style={styles.addonItemPrice} title={data.currency_symbol + funGetFrench_Curr(addons.add_ons_price, item.quantity, this.props.lan)} />
                                                                        </EDRTLView>
                                                                    )
                                                                }
                                                            )}
                                                        </View>)
                                                }
                                            )
                                            : null}
                                    </>
                                );
                            }}
                            keyExtractor={(item, index) => item + index}
                        />
                        <View style={styles.nextedView} />
                        <FlatList

                            scrollEnabled={true}
                            // data={this.state.discountedPrice !== undefined ? data.price.filter(p => p.value != 0 && p.label_key !== "Total").concat([{
                            //     label: strings("discount") + "(" + this.promoObj.coupon_name + ")",
                            //     label_key: "Discount",
                            //     value: this.promoObj.coupon_discount
                            // }]) : data.price.filter(p => p.value != 0 && p.label_key !== "Total")}
                            data={this.state.discountedPrice !== undefined ?
                                data.price.filter(p => p.value != 0 && p.label_key !== "Total").concat([{
                                    label: strings("discount") + "(" + (this.promoObj !== undefined && this.promoObj !== null && this.promoObj.coupon_arrayapply !== undefined ? this.promoObj.coupon_arrayapply.map(data => data.coupon_name).join(", ") : "") + ")",
                                    label_key: "Discount",
                                    value: this.promoObj.coupon_discount
                                }])
                                : data.price.filter(p => p.value != 0 && p.label_key !== "Total")

                            }
                            listKey={(item, index) => "Q" + index.toString()}
                            renderItem={item => this.renderPriceView(item.item, data.currency_symbol)}
                            keyExtractor={(item, index) => item + index}
                        />
                        <View style={[styles.nextedView, { marginVertical: 5 }]} />
                        <View style={styles.totalView}>
                            <PriceDetail
                                title={strings("total")}
                                style={{ marginRight: 5, marginLeft: 5 }}
                                titleStyle={styles.itemTextStyle}
                                priceStyle={styles.itemTextStyle}
                                price={this.arrayUpcoming[0].currency_symbol + funGetFrench_Curr(
                                    ((this.state.discountedPrice !== undefined ? this.state.discountedPrice : this.state.totalPendingAmount)
                                        +
                                        (this.state.selectedOption == "cod" ? 0 : Number(this.possible_creditcard_fee))), 1, this.arrayUpcoming[0].currency_symbol)}
                            />
                            {this.state.selectedOption !== "" &&
                                this.state.selectedOption !== "cod" &&
                                this.possible_creditcard_fee !== undefined &&
                                this.possible_creditcard_fee !== null &&
                                this.possible_creditcard_fee !== 0 ?
                                <EDRTLText title={"(" + strings("creditFreeIncluded") + " " + this.arrayUpcoming[0].currency_symbol +
                                    funGetFrench_Curr(this.possible_creditcard_fee, 1, this.arrayUpcoming[0].currency_symbol)
                                    + ")"}
                                    style={{
                                        marginHorizontal: 5,
                                        marginTop: 10,
                                        color: EDColors.black,
                                        fontFamily: EDFonts.semiBold,
                                        fontSize: getProportionalFontSize(12)
                                    }} /> : null

                            }
                        </View>
                        {data.extra_comment !== "" && data.extra_comment !== null ?
                            <>
                                <View style={styles.conmmentView} />
                                <View style={[styles.commentContainer, { flexDirection: isRTLCheck() ? "row-reverse" : "row" }]}>
                                    <Text style={{ color: EDColors.black }}>{strings("orderComment") + ': ' + data.extra_comment}</Text>
                                    {/* <Text style={{ color: EDColors.black }}>{data.extra_comment}</Text> */}
                                </View>
                            </> : null}

                    </View>
                </View>
            </TouchableOpacity>

        )
    }


    //#region 
    /** VIEW FOR PRICES */
    renderPriceView = (item, currency_symbol) => {
        return (
            <View style={{ flex: 1, paddingHorizontal: 2 }}>
                <PriceDetail
                    showToolTip={item.showToolTip}
                    taxable_fields={this.taxable_fields.filter(data => { return data.value !== "" && data.value != "0.00" && data.value != 0 })}
                    currency={this.arrayUpcoming.length !== 0 ? this.arrayUpcoming[0].currency_symbol : ""}

                    key={item.label}
                    title={item.label != undefined ? capiString(item.label) : ""}
                    price={
                        item.value != undefined
                            ? item.label_key.includes("Discount")
                                ? "- " + currency_symbol + funGetFrench_Curr(item.value, 1, currency_symbol)
                                : (item.label_key.includes("Delivery") || item.label_key.includes("Service")) ? (item.value.toString().includes("%") ? "+ " + item.value :
                                    "+ " + currency_symbol + funGetFrench_Curr(item.value, 1, currency_symbol))
                                    :
                                    currency_symbol + funGetFrench_Curr(item.value, 1, currency_symbol)
                            : ""
                    }
                    label_key={item.label_key}
                    titleStyle={styles.itemTextStyle}
                    priceStyle={styles.itemTextStyle}
                    style={{ marginRight: 5, marginLeft: 5 }}
                />
            </View>
        );
    }
    //#endregion

    //#region  NETWORK
    /** CHECK USER DEATILS */
    checkUser() {
        if (this.props.userID !== "" && this.props.userID !== undefined && this.props.userID !== null) {
            if (!this.state.isLoading)
                this.getPendingOrderData();
        } else {
            showDialogue(strings("loginValidation"), [], strings("appName"), () => {
                this.props.navigation.navigate("LoginContainer")
            });
        }
    }
    //#endregion

    //#region 
    /**
    * @param { Success Reponse Object } onSuccess
    */
    onSuccessOrderListing = (onSuccess) => {
        debugLog("ORDER DETAIL LIST ::::::::::::: ", onSuccess)
        if (onSuccess != undefined && onSuccess.status == RESPONSE_SUCCESS) {
            if (onSuccess.dineIn.length > 0) {
                this.arrayUpcoming = onSuccess.dineIn;
                this.updateData(this.arrayUpcoming);
                if (onSuccess.creditcard_apply !== undefined && onSuccess.creditcard_apply !== null &&
                    onSuccess.creditcard_apply.creditcard_fee_cal !== undefined &&
                    onSuccess.creditcard_apply.creditcard_fee_cal !== null &&
                    onSuccess.creditcard_apply.creditcard_fee_cal !== ""
                ) {
                    this.possible_creditcard_fee = onSuccess.creditcard_apply.creditcard_fee_cal
                    this.creditcard_details = onSuccess.creditcard_apply || {}
                }
            } else {
                this.strOnScreenMessageInProcess = strings('noDineIn')
            }
            // this.setState({ isLoading: false });
            this.getPaymentOptionsAPI()
        } else {
            console.log('NOT GETTING ORDER LIST')
            this.strOnScreenMessagePast = strings("generalWebServiceError")
            this.strOnScreenMessageInProcess = strings("generalWebServiceError")
            this.setState({ isLoading: false });
        }
    }


    /**
     * @param { Failure Response Object } onFailure
     */
    onFailureOrderListing = (onFailure) => { // ERROR 405
        console.log(':::::::::: FAILED TO GET ORDER', onFailure)
        this.strOnScreenMessagePast = strings("generalWebServiceError")
        this.strOnScreenMessageInProcess = strings("generalWebServiceError")
        this.setState({ isLoading: false });
    }

    /** GET PENDING ORDER API */
    getPendingOrderData() {
        netStatus(isConnected => {
            if (isConnected) {
                this.arrayUpcoming = []
                this.setState({ isLoading: true });
                let param = {
                    user_id: parseInt(this.props.userID) || 0,
                    // token: this.props.token,
                    language_slug: this.props.lan,
                    // unpaid_orders: this.unpaid_orders
                }
                getPayLaterOrdersAPI(param, this.onSuccessOrderListing, this.onFailureOrderListing, this.props);
            } else {
                this.setState({ isLoading: false })
                this.strOnScreenMessagePast = this.strOnScreenMessageInProcess = strings('noInternetTitle');
                this.strOnScreenSubtitlePast = this.strOnScreenSubtitleinProcess = strings('noInternet');
            }
        })
    }

    //#region 
    /** UPDATE DATA */
    updateData(arrayItems) {
        let totalPending = 0
        var arrayFinal = [];
        arrayItems.map((item, index) => {
            arrayFinal[index] = {
                isShow: true,
            };
            totalPending = totalPending + parseFloat(item.total)
        });
        this.isShowArray = arrayFinal;

        this.arrayUpcoming[0].price = this.arrayUpcoming[0].price.filter(data => { return data.label_key !== undefined })
        if (!this.isForPastOrder && this.arrayUpcoming[0].price !== undefined && this.arrayUpcoming[0].price !== null && this.arrayUpcoming[0].price instanceof Array) {
            this.taxable_fields = this.arrayUpcoming[0].price.filter(data => { return data.label_key !== undefined && (data.label_key.toLowerCase().includes("fee") || data.label_key.toLowerCase().includes("tax")) && data.value !== "" && data.value != "0.00" && data.value != 0 })
            let taxable_fields = this.taxable_fields
            this.arrayUpcoming[0].price = this.arrayUpcoming[0].price.filter(function (data) {
                return !taxable_fields.includes(data);
            });
            let total_taxes = 0
            if (taxable_fields.length !== 0) {
                taxable_fields.map(data => {
                    total_taxes = total_taxes + Number(data.value)
                })
            }
            this.arrayUpcoming[0].price.splice(
                this.arrayUpcoming[0].price.length - 1, 0, {
                label: strings("taxes&Fees") + " ",
                value: total_taxes,
                label_key: "Tax and Fee",
                showToolTip: true
            }
            )


            this.setState({ totalPendingAmount: totalPending, restaurant_id: arrayItems[0].restaurant_id })
        }
    }
    //#endregion
}

const styles = StyleSheet.create({
    pendingContainer: { flexDirection: "column", marginBottom: 10 },
    commentContainer: { marginHorizontal: 10, flexDirection: "row", marginTop: 5, marginBottom: 10 },
    pendingSubContainer: {
        flex: 1,
        margin: 5,
        padding: 5
        //  backgroundColor: EDColors.white, borderRadius: 6, shadowColor: EDColors.black,
        // shadowOffset: { width: 0, height: 2 },
        // shadowOpacity: 0.8,
        // shadowRadius: 2,
    },
    pendingIcon: { height: metrics.screenWidth * 0.25, width: metrics.screenWidth * 0.25, borderRadius: 8 },
    textStyle: {
        // flex: 1,
        color: EDColors.black,
        fontSize: getProportionalFontSize(20),
        fontFamily: EDFonts.regular,
        marginHorizontal: 10
    },
    nextedView: {
        backgroundColor: "#F6F6F6",
        height: 0.5,
        marginHorizontal: 0,
        marginBottom: 0
    },
    topView: { marginTop: 5 },
    nameText: { color: EDColors.black, fontFamily: EDFonts.semiBold, fontSize: getProportionalFontSize(16) },
    conmmentView: { borderColor: EDColors.black, borderWidth: .5, marginTop: 10 },
    pendingSubView: { justifyContent: "space-between", backgroundColor: EDColors.white, borderRadius: 16, padding: 8 },
    addonText: { fontSize: getProportionalFontSize(12), fontFamily: EDFonts.regular, color: EDColors.black, textDecorationLine: 'underline' },
    pastOrderText: {
        color: EDColors.text,
        fontSize: getProportionalFontSize(12),
        fontFamily: EDFonts.medium,

    },
    listStyle: { marginVertical: 0, borderTopColor: '#F6F6F6', borderTopWidth: 1 },
    totalView: { flex: 1, paddingBottom: 10, paddingHorizontal: 3 },
    detailView: { backgroundColor: EDColors.white, borderRadius: 16, padding: 5, marginTop: 10 },
    coupenBtn: { alignSelf: "center", marginRight: 10 },
    methodText: { fontFamily: EDFonts.semiBold, fontSize: getProportionalFontSize(16), color: EDColors.black },
    methodStyle: { marginHorizontal: 10, marginTop: 10 },
    itemTextStyle: { color: EDColors.black, fontFamily: EDFonts.medium, fontSize: getProportionalFontSize(12) },
    titleText: { fontFamily: EDFonts.semiBold, fontSize: getProportionalFontSize(16), color: EDColors.black, marginVertical: 8, },
    addonItemText: { fontFamily: EDFonts.regular, fontSize: getProportionalFontSize(12), color: EDColors.text, },
    textStylePrice: { alignItems: "center", justifyContent: 'space-between', marginTop: 10, marginHorizontal: 0 },
    statusText: { color: EDColors.black, fontFamily: EDFonts.semiBold, fontSize: getProportionalFontSize(12) },
    statusTextString: { color: EDColors.text, marginHorizontal: 0, fontFamily: EDFonts.regular, fontSize: getProportionalFontSize(12) },
    addonItemPrice: { textAlign: 'right', marginRight: -5, fontSize: getProportionalFontSize(12), fontFamily: EDFonts.regular, color: EDColors.text },
    mainContainer: { flex: 1, margin: 10 },
    orderParentView: { flex: 1, alignContent: 'center' },
    priceListStyle: { marginTop: 0, marginBottom: 10, marginHorizontal: 5 },
    discountView: { justifyContent: 'center', alignItems: 'center', },
    BtnStyle: {
        width: '100%',
        height: metrics.screenHeight * 0.070,
        borderRadius: 16,
        backgroundColor: EDColors.primary,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 10
    },
    btnText: {
        fontSize: getProportionalFontSize(14),
        fontFamily: EDFonts.medium,
        color: EDColors.white,
        marginHorizontal: 10
    },
    subContainer: {
        margin: 10,
        paddingVertical: 5,
        marginTop: 5,
    },
    paymentMethodTitle: {
        // flex: 1,
        fontFamily: EDFonts.medium,
        fontSize: getProportionalFontSize(14),
        padding: 10,
        marginHorizontal: 0,
        marginEnd: 5,
        // maxWidth: metrics.screenWidth * .25
    },
    addonView: {
        marginHorizontal: 0,
        marginVertical: 2
    },
    paymentContainer: {
        backgroundColor: EDColors.offWhite,
        borderRadius: 6,
        padding: 10,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.8,
        shadowRadius: 2,
        margin: 15,
    },
    btnView: {
        width: '95%',
        height: metrics.screenHeight * 0.070,
        borderRadius: 16,
        backgroundColor: EDColors.primary,
        justifyContent: 'center',
        alignItems: 'center',
        marginHorizontal: 10
    },
    paymentBtn: {
        width: '100%',
        borderRadius: 16,
        backgroundColor: EDColors.white,
        justifyContent: 'space-between',
        // alignItems:'center',
        marginVertical: 10
    },
    paymentBtnView: { justifyContent: 'space-between', flex: 1, paddingHorizontal: 10, alignItems: 'center' },
    promoView: {
        borderRadius: 16,
        marginLeft: 10,
        marginRight: 10,
        backgroundColor: "#fff",
        marginVertical: 5
    },
    promoResponse: {
        flexDirection: isRTLCheck() ? "row-reverse" : 'row',
        alignItems: "center",
        padding: 5,
    },
    promoResponseTextStyle: {
        // flex: 1,
        fontFamily: EDFonts.regular,
        fontSize: getProportionalFontSize(16),
        alignSelf: "center",
        color: EDColors.black,
        textAlign: "center",
        marginHorizontal: 10,
        // height: 20
        marginVertical: 10
    },
    promoCode: {
        alignSelf: "center",
        color: EDColors.text,
        fontFamily: EDFonts.medium,
        fontSize: getProportionalFontSize(14),
        marginTop: 15,
        marginBottom: 15,
        paddingHorizontal: 5
    },
    subContainer: {
        margin: 10,
        backgroundColor: "#fff",
        borderRadius: 16,
        padding: 10,
        paddingHorizontal: 15,
        marginHorizontal: 15

    },
    cardView: {
        alignItems: "center",
        justifyContent: "space-between",
        flex: 1,
        borderTopColor: EDColors.separatorColorNew,
        borderTopWidth: 1,
        paddingTop: 15,
        marginTop: 5,
        paddingHorizontal: 10
    },
    cardSubView: {
        alignItems: "center",
        flex: 1,

    },
    last4Text: {
        fontFamily: EDFonts.medium,
        fontSize: getProportionalFontSize(14),
        color: EDColors.black
    },
    expiredText: {
        fontFamily: EDFonts.regular,
        fontSize: getProportionalFontSize(13),
        color: EDColors.mastercard
    },
    changeCard: {
        fontFamily: EDFonts.semiBold,
        fontSize: getProportionalFontSize(13),
        color: EDColors.primary,
        // flex: 1,
        textAlign: "right",
        textDecorationLine: "underline",
        marginLeft: 10
    }
})

export default connect(
    state => {
        return {
            titleSelected: state.navigationReducer.selectedItem,
            checkoutDetail: state.checkoutReducer.checkoutDetail,
            lan: state.userOperations.lan,
            userID: state.userOperations.userIdInRedux,
            token: state.userOperations.phoneNumberInRedux,
            firstName: state.userOperations.firstName,
            lastName: state.userOperations.lastName
        };
    },
    dispatch => {
        return {
            saveNavigationSelection: dataToSave => {
                dispatch(saveNavigationSelection(dataToSave));
            },
            saveTableID: table_id => {
                dispatch(saveTableIDInRedux(table_id))
            },
            saveResID: table_id => {
                dispatch(saveResIDInRedux(table_id))
            }
        };
    }
)(PendingOrderContainer);