export const EDFonts = {
  bold: "Gilroy-Bold",
  semiBold: "Gilroy-SemiBold",
  extrabold: "Gilroy-ExtraBold",
    medium: "Gilroy-Medium",
    regular: "Gilroy-Regular",
    light: "Gilroy-Light",
  ultralight: "Gilroy-UltraLight",
    black: "Gilroy-Black",
    boldItalic: "Gilroy-BoldItalic",
    heavy: "Gilroy-Heavy",
    thin: "Gilroy-Thin",
};
